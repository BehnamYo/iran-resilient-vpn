import 'package:riverpod_annotation/riverpod_annotation.dart';
part 'analytics_controller.g.dart';

const String enableAnalyticsPrefKey = 'enable_analytics';

/// Analytics cannot be enabled in this fork, including by migrated preferences.
@Riverpod(keepAlive: true)
class AnalyticsController extends _$AnalyticsController {
  @override
  Future<bool> build() async => false;
  Future<void> enableAnalytics() async {
    state = const AsyncData(false);
  }

  Future<void> disableAnalytics() async {
    state = const AsyncData(false);
  }
}
