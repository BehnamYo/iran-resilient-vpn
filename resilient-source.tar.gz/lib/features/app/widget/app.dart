import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:hiddify/features/resilience/widget/resilience_home.dart';

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Resilient VPN',
    debugShowCheckedModeBanner: false,
    supportedLocales: const [Locale('en'), Locale('fa')],
    localizationsDelegates: GlobalMaterialLocalizations.delegates,
    theme: ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xff6ce6c3), brightness: Brightness.dark),
      scaffoldBackgroundColor: const Color(0xff0b1420),
      fontFamily: 'Shabnam',
    ),
    home: const ResilienceHome(),
  );
}
