import 'dart:async';
import '../data/engine_adapter.dart';
import '../data/history_store.dart';
import '../data/tunnel_probe.dart';
import '../model/candidate.dart';
import '../model/selection_state.dart';

class SelectionController {
  SelectionController(
    this.engine,
    this.history, {
    Future<ProbeResult> Function(Candidate, int)? verify,
    DateTime Function()? now,
  }) : _verify = verify,
       _now = now ?? DateTime.now;
  final EngineAdapter engine;
  final HistoryStore history;
  final Future<ProbeResult> Function(Candidate, int)? _verify;
  final DateTime Function() _now;
  final _events = StreamController<SelectionState>.broadcast(sync: true);
  Stream<SelectionState> get states => _events.stream;
  SelectionState current = const SelectionState(SelectionPhase.idle);
  int _generation = 0;
  bool _running = false;
  Completer<void> _cancelled = Completer<void>();
  final Map<String, DateTime> _cooldown = {};
  String _network = 'unknown';
  List<Candidate>? _remaining;
  void _emit(SelectionState s) {
    current = s;
    if (!_events.isClosed) _events.add(s);
  }

  List<Candidate> _ordered(List<Candidate> input, String network) {
    final list = [...input];
    final order = {for (var i = 0; i < input.length; i++) input[i].id: i};
    list.sort((a, b) {
      final sa = a.id == history.success[network] ? 0 : 1, sb = b.id == history.success[network] ? 0 : 1;
      if (sa != sb) return sa - sb;
      final ca = (_cooldown[a.id]?.isAfter(_now()) ?? false) ? 1 : 0,
          cb = (_cooldown[b.id]?.isAfter(_now()) ?? false) ? 1 : 0;
      if (ca != cb) return ca - cb;
      return order[a.id]! - order[b.id]!;
    });
    return list;
  }

  Stream<SelectionState> connect(List<Candidate> candidates, String networkContext) {
    if (_running || current.connected) return states;
    final resume = current.phase == SelectionPhase.paused && _network == networkContext;
    final allowed = {for (final c in candidates) c.id};
    final remaining = resume && _remaining != null
        ? _remaining!.where((c) => allowed.contains(c.id)).toList()
        : _ordered(candidates, networkContext);
    _remaining = remaining;
    _network = networkContext;
    _running = true;
    final token = ++_generation;
    _cancelled = Completer<void>();
    unawaited(_run(remaining, token));
    return states;
  }

  Future<void> _run(List<Candidate> remaining, int token) async {
    final started = _now();
    var attempt = 0;
    String? previousTransport, previousEndpoint;
    try {
      while (remaining.isNotEmpty && token == _generation) {
        final left = const Duration(seconds: 90) - _now().difference(started);
        if (left <= Duration.zero) {
          _emit(SelectionState(SelectionPhase.paused, attempt: attempt, message: 'budget'));
          return;
        }
        var index = remaining.indexWhere(
          (c) => c.transportGroup != previousTransport && c.endpoint != previousEndpoint,
        );
        if (index < 0) index = remaining.indexWhere((c) => c.transportGroup != previousTransport);
        if (index < 0) index = 0;
        final c = remaining.removeAt(index);
        attempt++;
        _emit(
          SelectionState(
            SelectionPhase.testing,
            attempt: attempt,
            total: attempt + remaining.length,
            protocol: c.protocol,
          ),
        );
        final attemptStart = _now();
        ProbeResult result;
        try {
          result = await Future.any([
            (() async {
              await engine.start(c);
              if (token != _generation) throw EngineCancelled();
              return await (_verify?.call(c, token) ??
                  const TunnelProbe().verify(c.id, token, engine.probeSession(c.id)));
            })(),
            _cancelled.future.then<ProbeResult>((_) => throw EngineCancelled()),
          ]).timeout(left < const Duration(seconds: 12) ? left : const Duration(seconds: 12));
        } on VpnConsentCancelled {
          if (token == _generation) {
            await engine.stop();
            _emit(const SelectionState(SelectionPhase.permissionCancelled));
          }
          return;
        } catch (e) {
          result = ProbeResult(
            candidateId: c.id,
            generation: token,
            state: ProbeState.failed,
            stage: e is TimeoutException ? 'timeout' : 'engine',
            timestamp: _now(),
            duration: _now().difference(attemptStart),
          );
        }
        if (token != _generation) return;
        if (result.candidateId != c.id || result.generation != token) {
          await engine.stop();
          _emit(const SelectionState(SelectionPhase.failed, message: 'stale-result'));
          return;
        }
        history.record(c, _network, result);
        if (result.state == ProbeState.verified || result.state == ProbeState.limited) {
          _emit(
            SelectionState(
              result.state == ProbeState.verified ? SelectionPhase.verified : SelectionPhase.limited,
              attempt: attempt,
              protocol: c.protocol,
            ),
          );
          return;
        }
        await engine.stop().timeout(const Duration(seconds: 3));
        if (token != _generation) return;
        _cooldown[c.id] = _now().add(const Duration(minutes: 5));
        previousTransport = c.transportGroup;
        previousEndpoint = c.endpoint;
        final pause = Duration(seconds: [5, 15, 30, 60][(attempt - 1).clamp(0, 3)]);
        final budgetLeft = const Duration(seconds: 90) - _now().difference(started);
        if (budgetLeft <= Duration.zero) continue;
        await Future.any([Future<void>.delayed(pause < budgetLeft ? pause : budgetLeft), _cancelled.future]);
      }
      if (token == _generation) _emit(SelectionState(SelectionPhase.exhausted, attempt: attempt));
    } catch (_) {
      if (token == _generation) _emit(const SelectionState(SelectionPhase.failed, message: 'stop-unconfirmed'));
    } finally {
      if (token == _generation) _running = false;
    }
  }

  Future<void> cancel() async {
    _remaining = null;
    _generation++;
    if (!_cancelled.isCompleted) _cancelled.complete();
    try {
      await engine.stop().timeout(const Duration(seconds: 3));
      _emit(const SelectionState(SelectionPhase.idle));
    } catch (_) {
      _emit(const SelectionState(SelectionPhase.failed, message: 'stop-unconfirmed'));
    }
    _running = false;
  }

  Future<void> networkChanged(String context) async {
    await cancel();
    _network = context;
    _cooldown.clear();
  }

  Future<void> dispose() async {
    await cancel();
    await _events.close();
  }
}
