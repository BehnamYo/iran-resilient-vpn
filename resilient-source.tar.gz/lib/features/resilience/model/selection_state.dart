enum SelectionPhase { idle, testing, verified, limited, paused, exhausted, permissionCancelled, failed }

class SelectionState {
  const SelectionState(this.phase, {this.attempt = 0, this.total = 0, this.protocol, this.message = ''});
  final SelectionPhase phase;
  final int attempt, total;
  final String? protocol;
  final String message;
  bool get connected => phase == SelectionPhase.verified || phase == SelectionPhase.limited;
}
