import 'dart:convert';
import 'package:crypto/crypto.dart';

/// Only the subscription parser constructs candidates. No feed routing settings.
class Candidate {
  Candidate({required this.sourceId, required this.shareUri, required Map<String, dynamic> outbound})
    : _encoded = jsonEncode(outbound),
      id = sha256.convert(utf8.encode(jsonEncode(outbound))).toString();
  final String sourceId;
  final String shareUri;
  final String id;
  final String _encoded;
  Map<String, dynamic> get outbound => jsonDecode(_encoded) as Map<String, dynamic>;
  String get endpoint => outbound['server'] as String;
  int get port => outbound['server_port'] as int;
  String get protocol => outbound['type'] as String;
  String get transportGroup {
    final o = outbound;
    return '$protocol/${(o['transport'] as Map?)?['type'] ?? 'tcp'}/${(o['tls'] as Map?)?['reality'] != null ? 'reality' : 'tls'}';
  }
}
