enum ProbeState { verified, limited, failed }

class ProbeResult {
  const ProbeResult({
    required this.candidateId,
    required this.generation,
    required this.state,
    required this.stage,
    required this.timestamp,
    required this.duration,
  });
  final String candidateId, stage;
  final int generation;
  final ProbeState state;
  final DateTime timestamp;
  final Duration duration;
}
