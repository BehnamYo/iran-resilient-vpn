import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:hiddify/hiddifycore/hiddify_core_service_provider.dart';
import '../data/resilience_runtime.dart';
import '../model/selection_state.dart';
import 'sources_page.dart';
import 'history_page.dart';

String tr(bool fa, String en, String persian) => fa ? persian : en;

class StatusPanel extends StatelessWidget {
  const StatusPanel({
    super.key,
    required this.state,
    required this.count,
    required this.fa,
    required this.onConnect,
    required this.onStop,
  });
  final SelectionState state;
  final int count;
  final bool fa;
  final VoidCallback onConnect, onStop;
  @override
  Widget build(BuildContext context) {
    final title = switch (state.phase) {
      SelectionPhase.idle => tr(fa, 'Ready offline', 'آماده با تنظیمات ذخیره‌شده'),
      SelectionPhase.testing => tr(fa, 'Testing', 'در حال آزمایش'),
      SelectionPhase.verified => tr(fa, 'Verified', 'تأیید انتقال داده'),
      SelectionPhase.limited => tr(fa, 'Limited connectivity', 'اتصال محدود'),
      SelectionPhase.paused => tr(fa, 'Testing paused', 'آزمایش متوقف شد'),
      SelectionPhase.permissionCancelled => tr(fa, 'VPN permission cancelled', 'مجوز VPN لغو شد'),
      SelectionPhase.exhausted => tr(fa, 'No working connection found', 'اتصال قابل استفاده پیدا نشد'),
      SelectionPhase.failed => tr(fa, 'Connection needs attention', 'اتصال نیاز به بررسی دارد'),
    };
    final color = state.phase == SelectionPhase.verified
        ? const Color(0xff6ce6c3)
        : state.phase == SelectionPhase.limited
        ? Colors.amber
        : Theme.of(context).colorScheme.primary;
    return Directionality(
      textDirection: fa ? TextDirection.rtl : TextDirection.ltr,
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Icon(state.connected ? Icons.shield_outlined : Icons.public_rounded, size: 52, color: color),
              const SizedBox(height: 18),
              Text(
                title,
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(color: color),
              ),
              const SizedBox(height: 12),
              Text(
                tr(
                  fa,
                  '$count cached profiles · untested until checked',
                  '$count تنظیم ذخیره‌شده · تا زمان آزمایش تأیید نشده',
                ),
                textAlign: TextAlign.center,
              ),
              if (state.phase == SelectionPhase.testing) ...[
                const SizedBox(height: 16),
                const LinearProgressIndicator(),
                const SizedBox(height: 8),
                Text(
                  tr(
                    fa,
                    'Attempt ${state.attempt} · ${state.protocol ?? ''}',
                    'تلاش ${state.attempt} · ${state.protocol ?? ''}',
                  ),
                  textAlign: TextAlign.center,
                ),
              ],
              if (state.connected) ...[
                const SizedBox(height: 12),
                Text(
                  state.phase == SelectionPhase.verified
                      ? tr(
                          fa,
                          'Two HTTPS destinations passed, including a repeated transfer. Other sites may still be blocked.',
                          'دو مقصد HTTPS و انتقال مجدد موفق بود. ممکن است سایت‌های دیگر همچنان مسدود باشند.',
                        )
                      : tr(
                          fa,
                          'Only some checks passed. This tunnel is kept open for you to try.',
                          'فقط بخشی از آزمایش‌ها موفق بود. تونل برای استفاده آزمایشی باز مانده است.',
                        ),
                ),
              ],
              if (state.phase == SelectionPhase.paused) ...[
                const SizedBox(height: 12),
                Text(
                  tr(
                    fa,
                    'The 90-second search budget ended. You can continue or change network.',
                    'بودجه ۹۰ ثانیه‌ای جستجو تمام شد. ادامه دهید یا شبکه را عوض کنید.',
                  ),
                ),
              ],
              const SizedBox(height: 20),
              FilledButton.icon(
                onPressed: state.connected || state.phase == SelectionPhase.testing
                    ? onStop
                    : count > 0
                    ? onConnect
                    : null,
                icon: Icon(
                  state.connected || state.phase == SelectionPhase.testing
                      ? Icons.stop_rounded
                      : Icons.power_settings_new,
                ),
                label: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  child: Text(
                    state.connected || state.phase == SelectionPhase.testing
                        ? tr(fa, 'Disconnect', 'قطع اتصال')
                        : state.phase == SelectionPhase.paused
                        ? tr(fa, 'Continue testing', 'ادامه آزمایش')
                        : tr(fa, 'Connect', 'اتصال'),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class ResilienceHome extends ConsumerStatefulWidget {
  const ResilienceHome({super.key});
  @override
  ConsumerState<ResilienceHome> createState() => _ResilienceHomeState();
}

class _ResilienceHomeState extends ConsumerState<ResilienceHome> with WidgetsBindingObserver {
  bool fa = false;
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    fa = WidgetsBinding.instance.platformDispatcher.locale.languageCode == 'fa';
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      unawaited(ref.read(hiddifyCoreServiceProvider).init());
      unawaited(ref.read(resilienceRuntimeProvider).refresh());
    }
  }

  Future<void> action(Future<void> Function() run) async {
    try {
      await run();
    } catch (_) {
      if (mounted)
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              tr(fa, 'Operation failed. Cached profiles were kept.', 'عملیات ناموفق بود. تنظیمات ذخیره‌شده حفظ شدند.'),
            ),
          ),
        );
    }
  }

  Future<void> importFile(ResilienceRuntime r) async {
    final picked = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['txt'],
      withData: false,
    );
    if (picked == null) return;
    final item = picked.files.single;
    if (item.size > 2 * 1024 * 1024 || item.path == null) throw const FormatException('Invalid import');
    await r.importBytes(await File(item.path!).readAsBytes());
  }

  Future<void> importQr(ResilienceRuntime r) async {
    var returned = false;
    final text = await Navigator.of(context).push<String>(
      MaterialPageRoute(
        builder: (context) => Scaffold(
          appBar: AppBar(title: Text(tr(fa, 'Scan share link', 'اسکن پیوند تنظیمات'))),
          body: MobileScanner(
            onDetect: (capture) {
              if (returned) return;
              for (final barcode in capture.barcodes) {
                final raw = barcode.rawValue;
                if (raw != null) {
                  returned = true;
                  Navigator.pop(context, raw);
                  break;
                }
              }
            },
          ),
        ),
      ),
    );
    if (text != null) await r.importBytes(Uint8List.fromList(utf8.encode(text)));
  }

  Future<void> export(ResilienceRuntime r, bool profiles) async {
    if (profiles) {
      final consent = await showDialog<bool>(
        context: context,
        builder: (context) => AlertDialog(
          title: Text(tr(fa, 'Export connection secrets?', 'خروجی اطلاعات اتصال؟')),
          content: Text(
            tr(
              fa,
              'This file contains server passwords and connection credentials. Share it only with someone you trust.',
              'این فایل شامل رمز سرورها و اطلاعات اتصال است. فقط با افراد مورد اعتماد به اشتراک بگذارید.',
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: Text(tr(fa, 'Cancel', 'لغو'))),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: Text(tr(fa, 'Export', 'خروجی'))),
          ],
        ),
      );
      if (consent != true) return;
    }
    final file = profiles ? await r.exports.exportProfiles(includeSecrets: true) : await r.exports.exportDiagnostics();
    await Share.shareXFiles([XFile(file.path)]);
  }

  @override
  Widget build(BuildContext context) {
    final r = ref.watch(resilienceRuntimeProvider);
    return Directionality(
      textDirection: fa ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Resilient VPN'),
          actions: [TextButton(onPressed: () => setState(() => fa = !fa), child: Text(fa ? 'English' : 'فارسی'))],
        ),
        body: SafeArea(
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 680),
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  Text(
                    tr(fa, 'A connection worth checking', 'اتصالی که باید آزمایش شود'),
                    style: Theme.of(context).textTheme.headlineMedium,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    tr(
                      fa,
                      'Cached access. Measured transfers. No account.',
                      'تنظیمات آفلاین. آزمایش انتقال. بدون حساب.',
                    ),
                  ),
                  const SizedBox(height: 20),
                  if (!r.ready)
                    Padding(
                      padding: const EdgeInsets.all(28),
                      child: r.message == 'initialization-failed'
                          ? Text(
                              tr(
                                fa,
                                'Local setup failed. Restart the app.',
                                'راه‌اندازی محلی ناموفق بود. برنامه را دوباره باز کنید.',
                              ),
                            )
                          : const Center(child: CircularProgressIndicator()),
                    )
                  else ...[
                    StatusPanel(
                      state: r.state,
                      count: r.available.length,
                      fa: fa,
                      onConnect: r.connect,
                      onStop: () => unawaited(r.stop()),
                    ),
                    const SizedBox(height: 12),
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            Text(
                              tr(fa, 'Offline inventory', 'تنظیمات آفلاین'),
                              style: Theme.of(context).textTheme.titleLarge,
                            ),
                            const SizedBox(height: 8),
                            Text(
                              tr(
                                fa,
                                'Last content update: ${r.snapshot!.updated.toLocal().toString().split('.').first}',
                                'آخرین تغییر محتوا: ${r.snapshot!.updated.toLocal().toString().split('.').first}',
                              ),
                            ),
                            const SizedBox(height: 6),
                            Text(
                              tr(
                                fa,
                                'Refreshes about every six hours while the app is running; opening it checks overdue updates.',
                                'در زمان اجرای برنامه تقریباً هر شش ساعت به‌روز می‌شود؛ با باز کردن برنامه، زمان به‌روزرسانی بررسی می‌شود.',
                              ),
                            ),
                            if (r.message.startsWith('refresh:'))
                              Padding(
                                padding: const EdgeInsets.only(top: 8),
                                child: Text(
                                  tr(
                                    fa,
                                    'Updated feeds: ${r.message.split(':')[1]} · failed: ${r.message.split(':')[2]}',
                                    'منابع به‌روزشده: ${r.message.split(':')[1]} · ناموفق: ${r.message.split(':')[2]}',
                                  ),
                                ),
                              ),
                            if (r.message == 'refresh-failed')
                              Text(
                                tr(
                                  fa,
                                  'Update unavailable; cached profiles retained.',
                                  'به‌روزرسانی در دسترس نیست؛ تنظیمات قبلی حفظ شدند.',
                                ),
                              ),
                            Wrap(
                              spacing: 8,
                              children: [
                                TextButton.icon(
                                  onPressed: r.busy ? null : () => unawaited(r.refresh(force: true)),
                                  icon: r.busy
                                      ? const SizedBox(
                                          width: 16,
                                          height: 16,
                                          child: CircularProgressIndicator(strokeWidth: 2),
                                        )
                                      : const Icon(Icons.refresh),
                                  label: Text(tr(fa, 'Refresh now', 'به‌روزرسانی')),
                                ),
                                TextButton(
                                  onPressed: () =>
                                      Navigator.push(context, MaterialPageRoute(builder: (_) => SourcesPage(fa: fa))),
                                  child: Text(tr(fa, 'Sources', 'منابع')),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        OutlinedButton.icon(
                          onPressed: () => action(() => importFile(r)),
                          icon: const Icon(Icons.file_open_outlined),
                          label: Text(tr(fa, 'Import file', 'ورود فایل')),
                        ),
                        OutlinedButton.icon(
                          onPressed: () => action(() => importQr(r)),
                          icon: const Icon(Icons.qr_code_scanner),
                          label: Text(tr(fa, 'Scan QR', 'اسکن QR')),
                        ),
                        OutlinedButton(
                          onPressed: () =>
                              Navigator.push(context, MaterialPageRoute(builder: (_) => HistoryPage(fa: fa))),
                          child: Text(tr(fa, 'Attempt history', 'تاریخچه تلاش‌ها')),
                        ),
                        OutlinedButton(
                          onPressed: () => action(() => export(r, false)),
                          child: Text(tr(fa, 'Redacted diagnostics', 'گزارش بدون اطلاعات اتصال')),
                        ),
                        OutlinedButton(
                          onPressed: () => action(() => export(r, true)),
                          child: Text(tr(fa, 'Export profiles', 'خروجی تنظیمات')),
                        ),
                      ],
                    ),
                  ],
                  const SizedBox(height: 24),
                  ExpansionTile(
                    title: Text(tr(fa, 'Prepare before an outage', 'آمادگی پیش از قطعی')),
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            Text(
                              tr(
                                fa,
                                'Keep this APK and a profile export offline. Try mobile data and Wi-Fi separately. Public proxy operators are unknown; use HTTPS for sensitive activity.',
                                'این APK و خروجی تنظیمات را آفلاین نگه دارید. اینترنت همراه و وای‌فای را جداگانه آزمایش کنید. گردانندگان پراکسی‌های عمومی ناشناس‌اند؛ برای فعالیت حساس از HTTPS استفاده کنید.',
                              ),
                            ),
                            const SizedBox(height: 12),
                            Text(
                              tr(
                                fa,
                                'A VPN still needs a reachable route outside the filtered network. It cannot restore a complete international disconnection. No result here diagnoses a national shutdown.',
                                'VPN همچنان به یک مسیر قابل دسترس بیرون از شبکه فیلترشده نیاز دارد. قطع کامل ارتباط بین‌المللی را بازسازی نمی‌کند. نتایج این برنامه تشخیص قطعی سراسری نیست.',
                              ),
                            ),
                            TextButton(
                              onPressed: () => launchUrl(
                                Uri.parse('https://psiphon.ca/en/download.html'),
                                mode: LaunchMode.externalApplication,
                              ),
                              child: Text(tr(fa, 'Official Psiphon download', 'دانلود رسمی سایفون')),
                            ),
                            TextButton(
                              onPressed: () => launchUrl(
                                Uri.parse('https://www.torproject.org/download/#android'),
                                mode: LaunchMode.externalApplication,
                              ),
                              child: Text(tr(fa, 'Official Tor Browser download', 'دانلود رسمی مرورگر تور')),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Text(
                    tr(
                      fa,
                      'Based on Hiddify v4.1.1 · Noncommercial open-source fork. No ads or analytics. Public source and license:',
                      'بر پایه Hiddify v4.1.1 · انشعاب متن‌باز غیرتجاری. بدون تبلیغات یا تحلیل‌گر. کد منبع و مجوز:',
                    ),
                  ),
                  TextButton(
                    onPressed: () => launchUrl(
                      Uri.parse('https://github.com/BehnamYo/iran-resilient-vpn'),
                      mode: LaunchMode.externalApplication,
                    ),
                    child: const Text('BehnamYo / iran-resilient-vpn'),
                  ),
                  const SizedBox(height: 24),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
