import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import '../data/resilience_runtime.dart';
import 'resilience_home.dart' show tr;

class SourcesPage extends ConsumerWidget {
  const SourcesPage({super.key, required this.fa});
  final bool fa;
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final r = ref.watch(resilienceRuntimeProvider);
    return Directionality(
      textDirection: fa ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        appBar: AppBar(title: Text(tr(fa, 'Configuration sources', 'منابع تنظیمات'))),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Text(
              tr(
                fa,
                'Eight public feeds from two maintainers. These are unverified community servers, not trusted or guaranteed endpoints. Disabling a source stops an active connection.',
                'هشت منبع عمومی از دو نگهدارنده. این سرورهای عمومی تأیید یا تضمین نشده‌اند. غیرفعال کردن منبع، اتصال فعال را قطع می‌کند.',
              ),
            ),
            for (final s in r.catalog)
              Card(
                child: SwitchListTile(
                  isThreeLine: true,
                  title: Text('${s.owner} / ${s.id}'),
                  subtitle: Text(
                    '${r.snapshot?.sources[s.id]?.length ?? 0} ${tr(fa, 'cached · untested', 'ذخیره‌شده · آزمایش‌نشده')}\n${s.path}',
                  ),
                  value: !r.disabledSources.contains(s.id),
                  onChanged: r.busy ? null : (enabled) => r.setSource(s.id, enabled),
                ),
              ),
            if (r.snapshot?.sources.containsKey('local') ?? false)
              SwitchListTile(
                title: Text(tr(fa, 'Imported profiles', 'تنظیمات واردشده')),
                value: !r.disabledSources.contains('local'),
                onChanged: (v) => r.setSource('local', v),
              ),
          ],
        ),
      ),
    );
  }
}
