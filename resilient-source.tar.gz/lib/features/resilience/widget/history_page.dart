import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import '../data/resilience_runtime.dart';
import 'resilience_home.dart' show tr;

class HistoryPage extends ConsumerWidget {
  const HistoryPage({super.key, required this.fa});
  final bool fa;
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final r = ref.watch(resilienceRuntimeProvider);
    return Directionality(
      textDirection: fa ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        appBar: AppBar(
          title: Text(tr(fa, 'Local attempt history', 'تاریخچه محلی تلاش‌ها')),
          actions: [TextButton(onPressed: r.clearHistory, child: Text(tr(fa, 'Clear', 'پاک کردن')))],
        ),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Text(
              tr(
                fa,
                'Up to 200 local records. No browsing history is collected.',
                'حداکثر ۲۰۰ رکورد محلی. سابقه مرور وب جمع‌آوری نمی‌شود.',
              ),
            ),
            if (r.history.records.isEmpty)
              Padding(
                padding: const EdgeInsets.all(24),
                child: Text(tr(fa, 'No attempts yet', 'هنوز آزمایشی انجام نشده')),
              ),
            for (final record in r.history.records)
              ListTile(
                leading: Icon(record['result'] == 'verified' ? Icons.check_circle_outline : Icons.info_outline),
                title: Text('${record['protocol']} · ${record['result']}'),
                subtitle: Text('${record['stage']} · ${record['milliseconds']} ms\n${record['time']}'),
              ),
          ],
        ),
      ),
    );
  }
}
