import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'subscription_parser.dart';
import '../model/candidate.dart';
import '../model/probe_result.dart';

class HistoryStore {
  HistoryStore([this.directory]);
  final Directory? directory;
  final Map<String, String> success = {};
  final Map<String, Candidate> _known = {};
  List<Candidate> get knownWorking => List.unmodifiable(_known.values);
  Future<void> flush() => _writes;
  final List<Map<String, dynamic>> records = [];
  Future<void> _writes = Future.value();
  Future<void> load() async {
    if (directory == null) return;
    try {
      final f = File('${directory!.path}/history.json');
      if (await f.length() > 2 * 1024 * 1024) return;
      final j = jsonDecode(await f.readAsString()) as Map;
      success.addAll((j['success'] as Map).cast<String, String>());
      for (final row in ((j['known'] as List?) ?? []).take(16)) {
        final cs = parseSubscription(Uint8List.fromList(utf8.encode(row['uri'] as String)), row['source'] as String);
        if (cs.length == 1) _known[cs.single.id] = cs.single;
      }
      for (final r in (j['records'] as List).take(200)) {
        records.add((r as Map).cast<String, dynamic>());
      }
    } catch (_) {
      /* History is optional; never block offline profiles. */
    }
  }

  void record(Candidate c, String network, ProbeResult r) {
    if (r.state == ProbeState.verified) {
      success[network] = c.id;
      _known.remove(c.id);
      _known[c.id] = c;
      while (_known.length > 16) {
        _known.remove(_known.keys.first);
      }
    } else if (success[network] == c.id) {
      success.remove(network);
    }
    records.insert(0, {
      'id': c.id,
      'network': network,
      'protocol': c.protocol,
      'result': r.state.name,
      'stage': r.stage,
      'time': r.timestamp.toUtc().toIso8601String(),
      'milliseconds': r.duration.inMilliseconds,
    });
    if (records.length > 200) records.removeRange(200, records.length);
    persist();
  }

  void persist() {
    if (directory == null) return;
    final data = jsonEncode({
      'success': success,
      'records': records,
      'known': _known.values.map((c) => {'source': c.sourceId, 'uri': c.shareUri}).toList(),
    });
    _writes = _writes
        .then((_) async {
          await directory!.create(recursive: true);
          final f = File('${directory!.path}/history.tmp');
          await f.writeAsString(data, flush: true);
          await f.rename('${directory!.path}/history.json');
        })
        .catchError((Object _) {});
  }

  Future<void> clear() async {
    success.clear();
    _known.clear();
    records.clear();
    persist();
    await _writes;
  }
}
