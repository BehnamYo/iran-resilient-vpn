import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:hiddify/core/directories/directories_provider.dart';
import 'package:hiddify/features/connection/data/connection_data_providers.dart';
import 'package:hiddify/features/connection/model/connection_status.dart';
import 'package:hiddify/features/profile/data/profile_data_providers.dart';
import '../domain/selection_controller.dart';
import '../model/selection_state.dart';
import '../model/candidate.dart';
import 'engine_adapter.dart';
import 'history_store.dart';
import 'snapshot_store.dart';
import 'source_catalog.dart';
import 'subscription_fetcher.dart';
import 'subscription_parser.dart';
import 'refresh_controller.dart';
import 'export_service.dart';

final resilienceRuntimeProvider = ChangeNotifierProvider<ResilienceRuntime>((ref) {
  final dirs = ref.watch(appDirectoriesProvider).requireValue;
  final repo = ref.watch(connectionRepositoryProvider);
  final engine = HiddifyEngineAdapter(repo, ref.watch(profilePathResolverProvider));
  final runtime = ResilienceRuntime(Directory('${dirs.baseDir.path}/resilience'), dirs.tempDir, engine);
  runtime.coreEvents = repo.watchConnectionStatus().listen((status) {
    if (status is Disconnected && runtime.selection?.current.connected == true) {
      unawaited(runtime.stop());
    }
  });
  unawaited(runtime.initialize());
  return runtime;
});

class ResilienceRuntime extends ChangeNotifier {
  ResilienceRuntime(this.directory, this.temp, this.engine, {this.fetcher});
  final SubscriptionFetcher? fetcher;
  final Directory directory, temp;
  final HiddifyEngineAdapter engine;
  late final SnapshotStore store = SnapshotStore(directory);
  late final HistoryStore history = HistoryStore(directory);
  SelectionController? selection;
  Snapshot? snapshot;
  RefreshController? refresher;
  List<Source> catalog = [];
  final Set<String> disabledSources = {};
  bool busy = false, ready = false, closed = false;
  String message = '', network = 'unknown', networkLabel = 'unknown';
  StreamSubscription<ConnectionStatus>? coreEvents;
  StreamSubscription<dynamic>? _net;
  StreamSubscription<SelectionState>? _selectionEvents;
  Timer? _refreshTimer, _debounce;
  SelectionState get state => selection?.current ?? const SelectionState(SelectionPhase.idle);
  List<Candidate> get available {
    final nodes = <String, Candidate>{};
    if (snapshot == null) return [];
    for (final c in [...history.knownWorking, ...snapshot!.candidates]) {
      if (!disabledSources.contains(c.sourceId)) nodes.putIfAbsent(c.id, () => c);
    }
    return nodes.values.take(maxProfiles).toList();
  }

  late final ExportService exports = ExportService(temp, history, () => snapshot!, inventory: () => available);
  void changed() {
    if (!closed) notifyListeners();
  }

  Future<void> initialize() async {
    try {
      catalog = (jsonDecode(await rootBundle.loadString('assets/resilience/sources.json')) as List)
          .map((v) => Source.fromJson((v as Map).cast<String, dynamic>()))
          .toList();
      if (catalog.length > 8) throw const FormatException('Too many sources');
      snapshot = await store.loadSnapshot();
      if (snapshot == null) {
        final sources = <String, List<String>>{};
        for (final s in catalog) {
          final cs = parseSubscription(
            Uint8List.fromList(utf8.encode(await rootBundle.loadString('assets/resilience/${s.id}.txt'))),
            s.id,
          );
          sources[s.id] = cs.map((c) => c.shareUri).toList();
        }
        snapshot = Snapshot(revision: 1, updated: DateTime.utc(2026, 10, 3), sources: sources, etags: {});
        await store.commitSnapshot(snapshot!);
      }
      try {
        final f = File('${directory.path}/disabled.json');
        if (await f.length() < 2048)
          disabledSources.addAll((jsonDecode(await f.readAsString()) as List).cast<String>());
      } catch (_) {}
      await history.load();
      await engine.stop();
      selection = SelectionController(engine, history);
      _selectionEvents = selection!.states.listen((_) => changed());
      refresher = RefreshController(
        catalog,
        store,
        fetcher ?? SubscriptionFetcher(proxyPort: () => engine.proxyPort),
        snapshot!,
      );
      _net = const EventChannel('org.goldis.resilientvpn/network').receiveBroadcastStream().listen(
        _networkEvent,
        onError: (Object _) {
          message = 'network-monitor-unavailable';
          changed();
        },
      );
      _refreshTimer = Timer.periodic(const Duration(hours: 6), (_) => unawaited(refresh()));
      ready = true;
      changed();
      unawaited(refresh());
    } catch (_) {
      message = 'initialization-failed';
      changed();
    }
  }

  bool _changingNetwork = false;
  bool _resumeAfterNetworkChange = false;
  Future<void> _networkStop = Future.value();
  void _networkEvent(dynamic event) {
    if (event is! Map) return;
    final next = event['context'] as String? ?? 'unknown';
    final label = event['label'] as String? ?? 'unknown';
    if (next == network) return;
    _resumeAfterNetworkChange |= state.connected || state.phase == SelectionPhase.testing;
    network = next;
    networkLabel = label;
    // Invalidate synchronously; only reconnect is debounced.
    _changingNetwork = true;
    _networkStop = selection?.networkChanged(label) ?? Future.value();
    changed();
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 500), () async {
      final pending = _networkStop;
      await pending;
      if (closed || network != next || !identical(pending, _networkStop)) return;
      _changingNetwork = false;
      if (_resumeAfterNetworkChange && label != 'offline') {
        _resumeAfterNetworkChange = false;
        selection?.connect(available, label);
      }
      if (label != 'offline') unawaited(refresh());
    });
  }

  Future<void> refresh({bool force = false}) async {
    if (refresher == null || busy || closed) return;
    busy = true;
    changed();
    try {
      final r = await refresher!.refresh(force: force);
      snapshot = r.snapshot;
      message = 'refresh:${r.updatedSources}:${r.failedSources}';
    } catch (_) {
      message = 'refresh-failed';
    } finally {
      busy = false;
      changed();
    }
  }

  void connect() {
    if (ready && !_changingNetwork) selection!.connect(available, networkLabel);
  }

  Future<void> stop() async {
    _resumeAfterNetworkChange = false;
    await selection?.cancel();
    changed();
  }

  Future<void> setSource(String id, bool enabled) async {
    if (enabled) {
      disabledSources.remove(id);
    } else {
      disabledSources.add(id);
    }
    await File('${directory.path}/disabled.json').writeAsString(jsonEncode(disabledSources.toList()), flush: true);
    if (state.connected || state.phase == SelectionPhase.testing) await stop();
    changed();
  }

  Future<void> importBytes(Uint8List bytes) async {
    if (busy || snapshot == null) throw StateError('Wait for refresh to finish');
    if (bytes.length > 2 * 1024 * 1024) throw const FormatException('Import exceeds limit');
    final cs = parseSubscription(bytes, 'local');
    if (cs.isEmpty) throw const FormatException('No supported secure profiles');
    final existing = snapshot!.candidates.where((c) => c.sourceId == 'local');
    final local = {
      for (final c in [...existing, ...cs]) c.id: c.shareUri,
    };
    final next = Snapshot(
      revision: snapshot!.revision + 1,
      updated: DateTime.now(),
      sources: {...snapshot!.sources, 'local': local.values.toList()},
      etags: snapshot!.etags,
    );
    await store.commitSnapshot(next);
    snapshot = next;
    refresher!.snapshot = next;
    message = 'imported:${cs.length}';
    changed();
  }

  Future<void> clearHistory() async {
    await history.clear();
    changed();
  }

  @override
  void dispose() {
    closed = true;
    _refreshTimer?.cancel();
    _debounce?.cancel();
    _net?.cancel();
    _selectionEvents?.cancel();
    coreEvents?.cancel();
    selection?.dispose();
    super.dispose();
  }
}
