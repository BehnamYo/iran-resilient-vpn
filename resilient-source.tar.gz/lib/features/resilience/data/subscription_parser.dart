import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import '../model/candidate.dart';

const maxProfiles = 2000;
const maxDecodedBytes = 8 * 1024 * 1024;

bool isPublicAddress(InternetAddress address) {
  final b = address.rawAddress;
  if (b.length == 4) {
    return !(b[0] == 0 ||
        b[0] == 10 ||
        b[0] == 127 ||
        b[0] >= 224 ||
        (b[0] == 100 && b[1] >= 64 && b[1] <= 127) ||
        (b[0] == 169 && b[1] == 254) ||
        (b[0] == 172 && b[1] >= 16 && b[1] <= 31) ||
        (b[0] == 192 && (b[1] == 168 || b[1] == 0 || b[1] == 2)) ||
        (b[0] == 198 && (b[1] == 18 || b[1] == 19 || b[1] == 51)) ||
        (b[0] == 203 && b[1] == 0 && b[2] == 113));
  }
  // Only global unicast. Exclude translation, tunnel and documentation prefixes.
  if ((b[0] & 0xe0) != 0x20) return false;
  if (b[0] == 0x20 && b[1] == 0x02) return false;
  if (b[0] == 0x20 && b[1] == 1 && (b[2] < 2 || (b[2] == 0x0d && b[3] == 0xb8))) return false;
  return true;
}

bool isPublicHost(String host) {
  final h = host.toLowerCase().replaceAll(RegExp(r'^\[|\]$'), '');
  final ip = InternetAddress.tryParse(h);
  if (ip != null) return isPublicAddress(ip);
  if (h.length > 253 ||
      !h.contains('.') ||
      h.endsWith('.') ||
      ['.local', '.localhost', '.internal', '.lan', '.home', '.invalid', '.test'].any(h.endsWith))
    return false;
  return h.split('.').every((p) => RegExp(r'^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$').hasMatch(p));
}

List<Candidate> parseSubscription(Uint8List bytes, String sourceId) {
  if (bytes.length > maxDecodedBytes) throw const FormatException('Subscription exceeds limit');
  final clock = Stopwatch()..start();
  var text = utf8.decode(bytes).trim();
  if (text.startsWith('{') || text.startsWith('['))
    throw const FormatException('Only supported share links are accepted');
  if (text.isNotEmpty && !text.contains('://')) {
    text = utf8.decode(base64.decode(base64.normalize(text.replaceAll(RegExp(r'\s'), '')))).trim();
    if (utf8.encode(text).length > maxDecodedBytes) throw const FormatException('Decoded subscription exceeds limit');
  }
  final result = <String, Candidate>{};
  for (final line in const LineSplitter().convert(text)) {
    if (clock.elapsed > const Duration(seconds: 5)) throw const FormatException('Parsing time limit');
    final value = line.trim();
    if (value.isEmpty || value.startsWith('#')) continue;
    if (utf8.encode(value).length > 16384) throw const FormatException('Entry exceeds limit');
    final candidate = _parse(value, sourceId);
    if (candidate != null) result.putIfAbsent(candidate.id, () => candidate);
    if (result.length > maxProfiles) throw const FormatException('Too many unique profiles');
  }
  return List.unmodifiable(result.values);
}

Candidate? _parse(String value, String sourceId) {
  try {
    final u = Uri.parse(value);
    final type = u.scheme == 'hy2' ? 'hysteria2' : u.scheme;
    if (!['vless', 'trojan', 'hysteria2'].contains(type) ||
        !u.hasPort ||
        u.port < 1 ||
        u.port > 65535 ||
        !isPublicHost(u.host))
      return null;
    final q = u.queryParameters;
    if (u.queryParametersAll.values.any((v) => v.length != 1)) return null;
    for (final k in ['allowInsecure', 'insecure', 'skip-cert-verify', 'allow_insecure']) {
      if (q.containsKey(k) && !['0', 'false'].contains(q[k]!.toLowerCase())) return null;
    }
    final security = q['security'] ?? (type == 'vless' ? 'none' : 'tls');
    if (!['tls', 'reality'].contains(security)) return null;
    if (security == 'reality' && type != 'vless') return null;
    final sni = q['sni'] ?? q['peer'] ?? u.host;
    if (!isPublicHost(sni)) return null;
    final credential = Uri.decodeComponent(u.userInfo);
    if (credential.isEmpty || credential.contains(RegExp(r'[\x00-\x1f]'))) return null;
    if (type == 'vless' && !RegExp(r'^[0-9a-fA-F]{8}(-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}$').hasMatch(credential))
      return null;
    var transport = q['type'] ?? 'tcp';
    if (transport == 'raw') transport = 'tcp';
    if (!['tcp', 'ws', 'grpc', 'httpupgrade'].contains(transport)) return null;
    if (type == 'hysteria2' && transport != 'tcp') return null;
    if (q['headerType'] != null && q['headerType'] != 'none') return null;
    final tls = <String, dynamic>{'enabled': true, 'server_name': sni};
    final accepted = <String, String>{'security': security, 'sni': sni};
    if (q['alpn']?.isNotEmpty ?? false) {
      final alpn = q['alpn']!.split(',');
      if (alpn.any((x) => !['h2', 'http/1.1', 'h3'].contains(x))) return null;
      tls['alpn'] = alpn;
      accepted['alpn'] = q['alpn']!;
    }
    final fp = q['fp'] ?? (security == 'reality' ? 'chrome' : null);
    if (fp != null && fp != 'none') {
      if (!['chrome', 'firefox', 'safari', 'ios', 'android', 'edge', 'random', 'randomized'].contains(fp)) return null;
      tls['utls'] = {'enabled': true, 'fingerprint': fp};
      accepted['fp'] = fp;
    }
    if (security == 'reality') {
      final key = q['pbk'] ?? '';
      final sid = q['sid'] ?? '';
      if (!RegExp(r'^[A-Za-z0-9_-]{43}$').hasMatch(key) || !RegExp(r'^(?:[0-9a-fA-F]{2}){0,8}$').hasMatch(sid))
        return null;
      tls['reality'] = {'enabled': true, 'public_key': key, 'short_id': sid};
      accepted.addAll({'pbk': key, 'sid': sid});
    }
    final o = <String, dynamic>{
      'type': type,
      'server': u.host.replaceAll(RegExp(r'^\[|\]$'), ''),
      'server_port': u.port,
      if (type == 'vless') 'uuid': credential.toLowerCase() else 'password': credential,
      'tls': tls,
    };
    if (type == 'vless' && (q['flow']?.isNotEmpty ?? false)) {
      if (q['flow'] != 'xtls-rprx-vision' || transport != 'tcp') return null;
      o['flow'] = q['flow'];
      accepted['flow'] = q['flow']!;
    }
    if (transport != 'tcp') {
      final t = <String, dynamic>{'type': transport};
      accepted['type'] = transport;
      if (transport == 'grpc') {
        final service = q['serviceName'] ?? '';
        t['service_name'] = service;
        accepted['serviceName'] = service;
      } else {
        final path = q['path'] ?? '/';
        final host = q['host'] ?? sni;
        if (!isPublicHost(host) || !path.startsWith('/') || path.contains(RegExp(r'[\x00-\x1f]'))) return null;
        t['path'] = path;
        if (transport == 'ws') {
          t['headers'] = {'Host': host};
        } else {
          t['host'] = host;
        }
        accepted.addAll({'path': path, 'host': host});
      }
      o['transport'] = t;
    }
    if (type == 'hysteria2' && q['obfs'] != null) {
      if (q['obfs'] != 'salamander' || (q['obfs-password']?.isEmpty ?? true)) return null;
      o['obfs'] = {'type': 'salamander', 'password': q['obfs-password']};
      accepted.addAll({'obfs': 'salamander', 'obfs-password': q['obfs-password']!});
    }
    final clean = Uri(
      scheme: type,
      userInfo: Uri.encodeComponent(credential),
      host: u.host,
      port: u.port,
      queryParameters: accepted,
    ).toString();
    return Candidate(sourceId: sourceId, shareUri: clean, outbound: o);
  } on FormatException {
    return null;
  }
}

String encodeEngineProfile(List<Candidate> candidates, {String? resolvedAddress}) => jsonEncode({
  'outbounds': [
    for (final c in candidates)
      {...c.outbound, 'tag': 'proxy-${c.id.substring(0, 12)}', if (resolvedAddress != null) 'server': resolvedAddress},
  ],
});
