class Source {
  const Source({required this.id, required this.owner, required this.repo, required this.ref, required this.path});
  final String id, owner, repo, ref, path;
  factory Source.fromJson(Map<String, dynamic> j) {
    final s = Source(
      id: j['id'] as String,
      owner: j['owner'] as String,
      repo: j['repo'] as String,
      ref: j['ref'] as String,
      path: j['path'] as String,
    );
    if (!RegExp(r'^[a-z0-9-]+$').hasMatch(s.id) ||
        ![s.owner, s.repo, s.ref].every((v) => RegExp(r'^[A-Za-z0-9_.-]+$').hasMatch(v)) ||
        s.path.split('/').any((v) => v.isEmpty || v == '.' || v == '..' || !RegExp(r'^[A-Za-z0-9_.-]+$').hasMatch(v))) {
      throw const FormatException('Invalid catalog source');
    }
    return s;
  }
  Uri get rawUri => Uri.https('raw.githubusercontent.com', '/$owner/$repo/$ref/$path');
  Uri get apiUri => Uri.https('api.github.com', '/repos/$owner/$repo/contents/$path', {'ref': ref});
}
