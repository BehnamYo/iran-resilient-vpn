import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/services.dart';
import 'package:hiddify/features/connection/data/connection_repository.dart';
import 'package:hiddify/features/connection/model/connection_failure.dart';
import 'package:hiddify/features/profile/data/profile_path_resolver.dart';
import 'package:hiddify/features/profile/model/profile_entity.dart';
import '../model/candidate.dart';
import 'subscription_parser.dart';
import 'tunnel_probe.dart';

class EngineCancelled implements Exception {}

class VpnConsentCancelled implements Exception {}

abstract interface class EngineAdapter {
  Future<void> start(Candidate candidate);
  Future<void> stop();
  ProbeSession probeSession(String candidateId);
}

class HiddifyEngineAdapter implements EngineAdapter {
  HiddifyEngineAdapter(this.repository, this.paths);
  final ConnectionRepository repository;
  final ProfilePathResolver paths;
  int _epoch = 0;
  String? activeId;
  Future<void>? _pending;
  final List<ProbeSession> _sessions = [];
  int? get proxyPort => activeId == null ? null : repository.configOptionsSnapshot?.mixedPort;
  void _check(int token) {
    if (token != _epoch) throw EngineCancelled();
  }

  @override
  Future<void> start(Candidate c) async {
    if (_pending != null) throw EngineCancelled();
    final token = ++_epoch;
    final operation = _start(c, token);
    _pending = operation;
    try {
      await operation;
    } finally {
      if (identical(operation, _pending)) _pending = null;
    }
  }

  Future<void> _start(Candidate c, int token) async {
    final stopped = await repository.disconnect().run();
    stopped.match((_) => throw StateError("Engine stop not confirmed"), (_) {});
    _check(token);
    final addresses = await InternetAddress.lookup(c.endpoint).timeout(const Duration(seconds: 3));
    _check(token);
    if (addresses.isEmpty || addresses.any((a) => !isPublicAddress(a)))
      throw const SocketException('Private or invalid endpoint address');
    // Pin the validated address to prevent a second resolution / DNS rebinding.
    final address = addresses.first.address;
    await paths.directory.create(recursive: true);
    _check(token);
    final file = paths.file('resilient-active');
    await file.writeAsString(encodeEngineProfile([c], resolvedAddress: address), flush: true);
    _check(token);
    final profile = ProfileEntity.local(
      id: 'resilient-active',
      active: true,
      name: 'Resilient VPN',
      lastUpdate: DateTime.now(),
      profileOverride: jsonEncode({
        'region': 'other',
        'rules': <dynamic>[],
        'enable-tun': true,
        'set-system-proxy': false,
        'allow-connection-from-lan': false,
        'bypass-lan': false,
        'strict-route': true,
        'use-xray-core-when-possible': false,
        'execute-config-as-is': false,
        'enable-clash-api': false,
        'remote-dns-address': 'https://1.1.1.1/dns-query',
        'direct-dns-address': '1.1.1.1',
        'warp': {'enable': false},
        'warp2': {'enable': false},
        'log-level': 'error',
      }),
    );
    final result = await repository.connect(profile, false).run();
    if (token != _epoch) {
      await repository.disconnect().run();
      throw EngineCancelled();
    }
    result.match(
      (failure) {
        if (failure is MissingVpnPermission) throw VpnConsentCancelled();
        throw StateError('Engine start failed');
      },
      (_) {
        activeId = c.id;
      },
    );
  }

  @override
  ProbeSession probeSession(String candidateId) {
    if (activeId != candidateId || proxyPort == null) throw EngineCancelled();
    final session = HttpProxySession(candidateId, proxyPort!);
    _sessions.add(session);
    return session;
  }

  @override
  Future<void> stop() async {
    _epoch++;
    if (Platform.isAndroid) {
      await const MethodChannel('com.hiddify.app/method').invokeMethod<void>('cancel-start');
    }
    for (final s in _sessions) {
      s.close();
    }
    _sessions.clear();
    final r = await repository.disconnect().run();
    r.match((_) => throw StateError('Engine stop not confirmed'), (_) {});
    activeId = null;
  }
}
