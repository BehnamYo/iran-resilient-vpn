import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'source_catalog.dart';
import 'subscription_parser.dart';

class WireResponse {
  const WireResponse(this.status, this.headers, this.bytes);
  final int status;
  final Map<String, String> headers;
  final Uint8List bytes;
}

typedef Transport = Future<WireResponse> Function(Uri uri, Map<String, String> headers);

class FetchResult {
  const FetchResult({this.bytes, this.etag, this.notModified = false, this.retryAfter});
  final Uint8List? bytes;
  final String? etag;
  final bool notModified;
  final Duration? retryAfter;
}

Future<Uint8List> decodeBounded(Uint8List bytes, String? encoding) async {
  if (bytes.length > 2 * 1024 * 1024) throw const FormatException('Transfer exceeds limit');
  Stream<List<int>> stream = Stream.value(bytes);
  if (encoding == 'gzip') {
    stream = stream.transform(gzip.decoder);
  } else if (encoding != null && encoding != 'identity') {
    throw const FormatException('Unsupported compression');
  }
  final output = BytesBuilder(copy: false);
  var size = 0;
  await for (final chunk in stream) {
    size += chunk.length;
    if (size > maxDecodedBytes) throw const FormatException('Decompression exceeds limit');
    output.add(chunk);
  }
  return output.takeBytes();
}

class SubscriptionFetcher {
  SubscriptionFetcher({Transport? transport, this.proxyPort}) : _transport = transport;
  final Transport? _transport;
  final int? Function()? proxyPort;
  static bool allowed(Uri u) =>
      u.scheme == 'https' &&
      u.userInfo.isEmpty &&
      u.port == 443 &&
      ['raw.githubusercontent.com', 'api.github.com'].contains(u.host);
  Future<WireResponse> _network(Uri uri, Map<String, String> headers) async {
    if (!allowed(uri)) throw const FormatException('Untrusted subscription URL');
    final client = HttpClient()
      ..autoUncompress = false
      ..connectionTimeout = const Duration(seconds: 8);
    final port = proxyPort?.call();
    if (port != null) {
      client.findProxy = (_) => 'PROXY 127.0.0.1:$port';
    }
    client.connectionFactory = (u, proxyHost, proxyPort) async {
      if (proxyHost != null) {
        if (proxyHost != '127.0.0.1' || port != proxyPort) throw const SocketException('Unexpected proxy');
        return Socket.startConnect(InternetAddress.loopbackIPv4, proxyPort!);
      }
      final addresses = await InternetAddress.lookup(u.host).timeout(const Duration(seconds: 5));
      if (addresses.isEmpty || addresses.any((a) => !isPublicAddress(a)))
        throw const SocketException('Nonpublic DNS answer');
      return Socket.startConnect(addresses.first, u.port);
    };
    try {
      return await (() async {
        final request = await client.getUrl(uri);
        request.followRedirects = false;
        headers.forEach(request.headers.set);
        final response = await request.close();
        final output = BytesBuilder(copy: false);
        var size = 0;
        await for (final chunk in response.timeout(const Duration(seconds: 5))) {
          size += chunk.length;
          if (size > 2 * 1024 * 1024) throw const FormatException('Transfer exceeds limit');
          output.add(chunk);
        }
        final hs = <String, String>{};
        response.headers.forEach((k, v) => hs[k.toLowerCase()] = v.join(','));
        return WireResponse(response.statusCode, hs, output.takeBytes());
      })().timeout(const Duration(seconds: 15));
    } finally {
      client.close(force: true);
    }
  }

  Future<WireResponse> _get(Uri start, Map<String, String> headers) async {
    var uri = start;
    for (var i = 0; i <= 3; i++) {
      if (!allowed(uri)) throw const FormatException('Untrusted redirect');
      final response = await (_transport ?? _network)(uri, headers);
      if ([301, 302, 303, 307, 308].contains(response.status)) {
        final location = response.headers['location'];
        if (location == null || i == 3) throw const FormatException('Invalid redirect');
        uri = uri.resolve(location);
        continue;
      }
      return response;
    }
    throw const FormatException('Redirect limit');
  }

  Duration _retry(String? value) {
    final seconds = int.tryParse(value ?? '');
    if (seconds != null) return Duration(seconds: seconds.clamp(1, 86400));
    try {
      return HttpDate.parse(value!).difference(DateTime.now()).isNegative
          ? const Duration(seconds: 60)
          : HttpDate.parse(value).difference(DateTime.now());
    } catch (_) {
      return const Duration(minutes: 15);
    }
  }

  Future<FetchResult> fetch(Source source, String? etag) async {
    final headers = {
      'User-Agent': 'ResilientVPN/1',
      'Accept-Encoding': 'gzip',
      if (etag != null) 'If-None-Match': etag,
    };
    WireResponse? raw;
    try {
      raw = await _get(source.rawUri, headers);
    } on Exception {
      /* GitHub API may remain reachable when raw host is blocked. */
    }
    if (raw?.status == 304) return const FetchResult(notModified: true);
    if (raw?.status == 429 || raw?.status == 403) return FetchResult(retryAfter: _retry(raw!.headers['retry-after']));
    if (raw?.status == 200)
      return FetchResult(
        bytes: await decodeBounded(raw!.bytes, raw.headers['content-encoding']),
        etag: raw.headers['etag'],
      );
    final api = await _get(source.apiUri, {
      'User-Agent': 'ResilientVPN/1',
      'Accept': 'application/vnd.github+json',
      'Accept-Encoding': 'gzip',
    });
    if (api.status == 429 || api.status == 403) return FetchResult(retryAfter: _retry(api.headers['retry-after']));
    if (api.status != 200) throw const HttpException('Subscription unavailable');
    final decoded = await decodeBounded(api.bytes, api.headers['content-encoding']);
    final obj = jsonDecode(utf8.decode(decoded));
    if (obj is! Map || obj['encoding'] != 'base64' || obj['content'] is! String)
      throw const FormatException('Invalid GitHub content');
    final bytes = base64.decode((obj['content'] as String).replaceAll(RegExp(r'\s'), ''));
    if (bytes.length > maxDecodedBytes) throw const FormatException('Decoded content exceeds limit');
    return FetchResult(bytes: bytes);
  }
}
