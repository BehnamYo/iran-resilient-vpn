import 'dart:convert';
import 'dart:io';
import 'history_store.dart';
import 'snapshot_store.dart';
import '../model/candidate.dart';

class ExportService {
  ExportService(this.directory, this.history, this.snapshot, {this.inventory});
  final List<Candidate> Function()? inventory;
  final Directory directory;
  final HistoryStore history;
  final Snapshot Function() snapshot;
  Future<File> exportDiagnostics() async {
    final rows = history.records
        .map(
          (r) => {
            for (final key in ['protocol', 'result', 'stage', 'milliseconds']) key: r[key],
          },
        )
        .toList();
    await directory.create(recursive: true);
    return File('${directory.path}/resilient-diagnostics.json').writeAsString(
      jsonEncode({'version': 1, 'count': (inventory?.call() ?? snapshot().candidates).length, 'attempts': rows}),
      flush: true,
    );
  }

  Future<File> exportProfiles({required bool includeSecrets}) async {
    if (!includeSecrets) throw StateError('Explicit credential export consent required');
    await directory.create(recursive: true);
    return File(
      '${directory.path}/resilient-profiles.txt',
    ).writeAsString((inventory?.call() ?? snapshot().candidates).map((c) => c.shareUri).join('\n'), flush: true);
  }
}
