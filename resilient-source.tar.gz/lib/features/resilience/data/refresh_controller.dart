import 'dart:convert';
import 'dart:io';
import 'source_catalog.dart';
import 'snapshot_store.dart';
import 'subscription_fetcher.dart';
import 'subscription_parser.dart';

class RefreshResult {
  const RefreshResult(this.snapshot, this.updatedSources, this.failedSources);
  final Snapshot snapshot;
  final int updatedSources, failedSources;
}

class RefreshController {
  RefreshController(this.catalog, this.store, this.fetcher, this.snapshot);
  final List<Source> catalog;
  final SnapshotStore store;
  final SubscriptionFetcher fetcher;
  Snapshot snapshot;
  Future<RefreshResult>? _running;
  final Map<String, DateTime> _retryAt = {};
  Future<RefreshResult> refresh({bool force = false}) {
    if (_running != null) return _running!;
    final task = _refresh(force);
    _running = task;
    return task.whenComplete(() => _running = null);
  }

  Future<RefreshResult> _refresh(bool force) async {
    final meta = File('${store.directory.path}/refresh-meta.json');
    DateTime? lastAttempt;
    try {
      if (await meta.exists() && await meta.length() < 16384) {
        final saved = jsonDecode(await meta.readAsString()) as Map;
        lastAttempt = DateTime.tryParse(saved['checked'] as String);
        (saved['retryAt'] as Map).forEach((key, value) {
          _retryAt[key as String] = DateTime.parse(value as String);
        });
      }
    } catch (_) {
      /* Invalid scheduling metadata cannot invalidate profiles. */
    }
    if (!force && lastAttempt != null && DateTime.now().difference(lastAttempt) < const Duration(hours: 6))
      return RefreshResult(snapshot, 0, 0);
    var updated = 0;
    var failed = 0;
    for (final source in catalog) {
      if ((_retryAt[source.id] ?? DateTime(1970)).isAfter(DateTime.now())) {
        failed++;
        continue;
      }
      try {
        final r = await fetcher.fetch(source, snapshot.etags[source.id]);
        if (r.retryAfter != null) {
          _retryAt[source.id] = DateTime.now().add(r.retryAfter!);
          failed++;
          continue;
        }
        if (r.notModified) continue;
        final cs = parseSubscription(r.bytes!, source.id);
        if (cs.isEmpty) throw const FormatException('Empty source');
        final etags = {...snapshot.etags}..remove(source.id);
        if (r.etag != null) etags[source.id] = r.etag!;
        final next = Snapshot(
          revision: snapshot.revision + 1,
          updated: DateTime.now(),
          sources: {...snapshot.sources, source.id: cs.map((c) => c.shareUri).toList()},
          etags: etags,
        );
        await store.commitSnapshot(next);
        snapshot = next;
        updated++;
      } catch (_) {
        failed++;
      }
    }
    await store.directory.create(recursive: true);
    final staged = File('${meta.path}.tmp');
    await staged.writeAsString(
      jsonEncode({
        'checked': DateTime.now().toUtc().toIso8601String(),
        'retryAt': _retryAt.map((k, v) => MapEntry(k, v.toUtc().toIso8601String())),
      }),
      flush: true,
    );
    await staged.rename(meta.path);
    return RefreshResult(snapshot, updated, failed);
  }
}
