import 'dart:async';
import 'dart:io';
import 'dart:typed_data';
import 'package:crypto/crypto.dart';
import '../model/probe_result.dart';
export '../model/probe_result.dart';

class ProbePayload {
  const ProbePayload(this.status, this.bytes);
  final int status;
  final Uint8List bytes;
}

abstract interface class ProbeSession {
  String get candidateId;
  Future<ProbePayload> request(Uri uri);
  void close();
}

/// There is deliberately no DIRECT entry or environment proxy lookup.
class HttpProxySession implements ProbeSession {
  HttpProxySession(this.candidateId, int port) {
    if (port < 1 || port > 65535) throw ArgumentError('Invalid engine port');
    _client = HttpClient()
      ..connectionTimeout = const Duration(seconds: 3)
      ..findProxy = (_) => 'PROXY 127.0.0.1:$port';
    _client.connectionFactory = (uri, host, p) {
      if (host != '127.0.0.1' || p != port) throw const SocketException('Probe escaped engine proxy');
      return Socket.startConnect(InternetAddress.loopbackIPv4, port);
    };
  }
  @override
  final String candidateId;
  late final HttpClient _client;
  @override
  Future<ProbePayload> request(Uri uri) async {
    final req = await _client.getUrl(uri);
    req.followRedirects = false;
    final res = await req.close();
    final bytes = BytesBuilder(copy: false);
    var size = 0;
    await for (final chunk in res.timeout(const Duration(seconds: 3))) {
      size += chunk.length;
      if (size > 65536) throw const FormatException('Probe payload limit');
      bytes.add(chunk);
    }
    return ProbePayload(res.statusCode, bytes.takeBytes());
  }

  @override
  void close() => _client.close(force: true);
}

class TunnelProbe {
  const TunnelProbe({this.timeout = const Duration(seconds: 8), this.sustain = const Duration(seconds: 2)});
  final Duration timeout, sustain;
  static final endpoints = [
    Uri.parse('https://www.gstatic.com/recaptcha/api2/logo_48.png'),
    Uri.parse('https://detectportal.firefox.com/success.txt'),
  ];
  static const hashes = [
    '1b9efb22c938500971aac2b2130a475fa23684dd69e43103894968df83145b8a',
    '81b2bd4ea98c8db66554fbc8d7637a1a69a130f331feb732b75caab4c4868fd5',
  ];
  Future<ProbeResult> verify(String id, int generation, ProbeSession session) async {
    final clock = Stopwatch()..start();
    var passed = 0;
    Future<bool> check(int index) async {
      try {
        final r = await session.request(endpoints[index]);
        return r.status == 200 && sha256.convert(r.bytes).toString() == hashes[index];
      } catch (_) {
        return false;
      }
    }

    ProbeState state = ProbeState.failed;
    var stage = 'payload';
    try {
      if (session.candidateId != id) {
        stage = 'candidate-mismatch';
      } else {
        state = await (() async {
          final results = await Future.wait([check(0), check(1)]);
          passed = results.where((x) => x).length;
          if (passed != 2) return passed == 1 ? ProbeState.limited : ProbeState.failed;
          await Future<void>.delayed(sustain);
          return await check(0) ? ProbeState.verified : ProbeState.limited;
        })().timeout(timeout);
      }
    } on TimeoutException {
      stage = 'timeout';
      state = passed > 0 ? ProbeState.limited : ProbeState.failed;
    } finally {
      session.close();
    }
    return ProbeResult(
      candidateId: id,
      generation: generation,
      state: state,
      stage: state == ProbeState.verified ? 'verified' : stage,
      timestamp: DateTime.now(),
      duration: clock.elapsed,
    );
  }
}
