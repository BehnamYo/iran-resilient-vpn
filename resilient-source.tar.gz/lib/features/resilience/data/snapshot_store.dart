import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import '../model/candidate.dart';
import 'subscription_parser.dart';

class Snapshot {
  Snapshot({
    required this.revision,
    required this.updated,
    required Map<String, List<String>> sources,
    required Map<String, String> etags,
  }) : sources = Map.unmodifiable(sources.map((k, v) => MapEntry(k, List<String>.unmodifiable(v)))),
       etags = Map.unmodifiable(etags);
  final int revision;
  final DateTime updated;
  final Map<String, List<String>> sources;
  final Map<String, String> etags;
  List<Candidate> get candidates {
    final result = <String, Candidate>{};
    if (sources.length > 9) throw const FormatException('Source count exceeds limit');
    for (final e in sources.entries) {
      final cs = parseSubscription(Uint8List.fromList(utf8.encode(e.value.join('\n'))), e.key);
      if (cs.length != e.value.length) throw const FormatException('Snapshot contains invalid or duplicate records');
      for (final c in cs) {
        result.putIfAbsent(c.id, () => c);
      }
    }
    if (result.length > maxProfiles) throw const FormatException('Inventory exceeds limit');
    return List.unmodifiable(result.values);
  }

  Map<String, dynamic> toJson() => {
    'revision': revision,
    'updated': updated.toUtc().toIso8601String(),
    'sources': sources,
    'etags': etags,
  };
  factory Snapshot.fromJson(Map<String, dynamic> j) => Snapshot(
    revision: j['revision'] as int,
    updated: DateTime.parse(j['updated'] as String),
    sources: (j['sources'] as Map).map((k, v) => MapEntry(k as String, (v as List).cast<String>())),
    etags: (j['etags'] as Map).cast<String, String>(),
  );
}

class SnapshotStore {
  SnapshotStore(this.directory, {this.beforeReplace});
  final Directory directory;
  final Future<void> Function()? beforeReplace;
  Future<void> _queue = Future.value();
  File _file(String name) => File('${directory.path}/$name.json');
  Future<Snapshot?> loadSnapshot() async {
    for (final name in ['current', 'previous-0', 'previous-1', 'previous-2']) {
      try {
        final f = _file(name);
        if (!await f.exists() || await f.length() > maxDecodedBytes) continue;
        final s = Snapshot.fromJson(jsonDecode(await f.readAsString()) as Map<String, dynamic>);
        if (s.candidates.isNotEmpty) return s;
      } catch (_) {
        /* Recover next validated snapshot. Never load staged files. */
      }
    }
    return null;
  }

  Future<void> commitSnapshot(Snapshot next) {
    final operation = _queue.then((_) => _commit(next));
    _queue = operation.catchError((Object _) {});
    return operation;
  }

  Future<void> _commit(Snapshot next) async {
    if (next.candidates.isEmpty) throw const FormatException('Empty inventory cannot replace cache');
    final data = jsonEncode(next.toJson());
    if (utf8.encode(data).length > maxDecodedBytes) throw const FormatException('Snapshot too large');
    await directory.create(recursive: true);
    final staged = File('${directory.path}/next.tmp');
    await staged.writeAsString(data, flush: true);
    for (var i = 2; i >= 0; i--) {
      final from = _file(i == 0 ? 'current' : 'previous-${i - 1}');
      if (await from.exists()) {
        final temp = File('${directory.path}/previous-$i.tmp');
        await temp.writeAsBytes(await from.readAsBytes(), flush: true);
        await temp.rename(_file('previous-$i').path);
      }
    }
    await beforeReplace?.call();
    await staged.rename(_file('current').path);
  }
}
