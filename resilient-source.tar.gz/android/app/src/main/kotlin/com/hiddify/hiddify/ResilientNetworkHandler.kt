package com.hiddify.hiddify

import android.net.Network
import android.net.NetworkCapabilities
import com.hiddify.hiddify.bg.DefaultNetworkListener
import io.flutter.embedding.engine.plugins.FlutterPlugin
import io.flutter.plugin.common.EventChannel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/** Observe the same selected underlying route as the engine, not all available networks. */
class ResilientNetworkHandler : FlutterPlugin, EventChannel.StreamHandler {
    private lateinit var channel: EventChannel
    private var sink: EventChannel.EventSink? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var registered = false
    override fun onAttachedToEngine(binding: FlutterPlugin.FlutterPluginBinding) {
        channel = EventChannel(binding.binaryMessenger, "org.goldis.resilientvpn/network")
        channel.setStreamHandler(this)
    }
    private fun emit(network: Network?) {
        scope.launch {
            val caps = network?.let { Application.connectivity.getNetworkCapabilities(it) }
            val label = when {
                network == null -> "offline"
                caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true -> "wifi"
                caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true -> "mobile"
                else -> "other"
            }
            sink?.success(mapOf("context" to (network?.toString() ?: "offline"), "label" to label))
        }
    }
    override fun onListen(arguments: Any?, events: EventChannel.EventSink) {
        sink = events
        if (!registered) {
            registered = true
            scope.launch { DefaultNetworkListener.start(this@ResilientNetworkHandler) { emit(it) } }
        }
    }
    override fun onCancel(arguments: Any?) {
        sink = null
        if (registered) {
            registered = false
            scope.launch { DefaultNetworkListener.stop(this@ResilientNetworkHandler) }
        }
    }
    override fun onDetachedFromEngine(binding: FlutterPlugin.FlutterPluginBinding) {
        onCancel(null)
        channel.setStreamHandler(null)
    }
}
