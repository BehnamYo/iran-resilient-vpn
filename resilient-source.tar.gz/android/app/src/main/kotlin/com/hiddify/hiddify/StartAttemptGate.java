package com.hiddify.hiddify;

/** Activity-result callbacks retain their original generation, even after cancellation. */
public final class StartAttemptGate {
    private long generation = 0;
    private long permission = -1;
    private boolean active = false;
    public synchronized long begin() {
        if (permission != -1) return -1;
        active = true;
        return ++generation;
    }
    public synchronized boolean isCurrent(long token) {
        return active && token == generation;
    }
    public synchronized void awaitPermission(long token) {
        if (isCurrent(token)) permission = token;
    }
    public synchronized long consumePermission() {
        long token = permission;
        permission = -1;
        return isCurrent(token) ? token : -1;
    }
    public synchronized void cancel() { active = false; ++generation; }
}
