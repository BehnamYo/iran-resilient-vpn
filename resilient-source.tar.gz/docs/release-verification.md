# Release verification — in progress

## Observed

- Official stable upstream production code compiles locally after fixing missing
  SDK/JDK components in the build environment.
- All 53 Flutter unit/widget tests passed after the independent review fix pass.
- The native consent-generation regression test passes under Java 17.
- Independent review found four Important issues: native permission cancellation,
  ignored shutdown failure, search starvation across budget pauses, and observing
  available rather than selected networks. These received one fix pass; there was
  no second independent review. Native Android behavior still requires device testing.
- The selected-network observer now shares DefaultNetworkListener with the engine.
  Dart invalidates attempts immediately and only delays reconnection by 500 ms.
- A real loopback HTTP server was reachable directly; a request explicitly routed
  to a closed local proxy port failed and made zero direct requests.
- Pinned resources inspected 3 October 2026:
  https://www.gstatic.com/recaptcha/api2/logo_48.png (200, 2,228 bytes)
  and https://detectportal.firefox.com/success.txt (200, 8 bytes).
  Expected SHA-256 digests are in tunnel_probe.dart. Changed payloads will fail
  conservatively until a source update, rather than produce false verification.

## Not yet verified

- Final signed custom APK and corresponding source in GitHub Actions.
- Installation, Android VPN consent, real engine routing, force-stop/relaunch,
  Wi-Fi/mobile changes, always-on/lockdown and DNS/IPv4/IPv6 leak behavior on Android.
- Connectivity on an Iranian network. A desktop test cannot establish this.

No Android device is attached and no hardware-accelerated Android runtime was found.
An eventual APK without those tests must be labelled **build-only / experimental**.
Enable Android's Always-on VPN and Block connections without VPN only after testing
that this build can establish a tunnel; otherwise those settings can block access.

Do not publish local debug or intermediate binaries. Use the reviewed Actions
workflow and verify its signature and source archive before delivery.
