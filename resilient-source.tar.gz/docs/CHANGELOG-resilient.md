# Resilient VPN changes

Based on Hiddify v4.1.1. Noncommercial fork under the unchanged LICENSE.md.

- Separate Android ID, icon and Persian/English home; no account, ads or analytics initialization.
- 434 unique sanitized, untested public bootstrap profiles from eight feeds / two maintainers.
- VLESS TLS/Reality, Trojan TLS and Hysteria2 share-link parsing; TCP, WebSocket,
  gRPC and HTTP upgrade where supported. Unsupported/plaintext/insecure entries skipped.
  Structured engine configs rejected instead of trusting arbitrary routing/DNS fields.
- GitHub raw + inline Contents API fallback, bounded transfer/decompression, ETag,
  persisted rate-limit cooldowns and six-hour best-effort refresh while running.
- Atomic private cache and three prior snapshots; up to 16 verified credentials retained
  separately so source churn does not remove known-working connections.
- Two pinned authenticated HTTPS payloads and a delayed repeat through the engine's
  explicit loopback proxy. No direct fallback. Only tested destinations are verified.
- One tunnel at a time, last-success priority, transport diversity, cancellation,
  12-second candidate timeout, 90-second search budget and 5/15/30/60-second backoff.
  No separate light probes (zero concurrency is within the maximum of three).
- File and camera QR import, consented credential export, redacted local diagnostics.
- Android underlying-network events contain no SSID, IP or location. App storage is
  private and Android backups disabled. Settings rejection now prevents connection.

Limitations: DNS tunneling is not implemented. No private server is provisioned.
A total international disconnection cannot be restored by a VPN alone. Public
operators are unknown. No claim of working connectivity in Iran has been measured.
Android device tests, leak tests and GitHub Actions release status must be read in
release-verification.md before treating a build as tested or ready for reliance.
