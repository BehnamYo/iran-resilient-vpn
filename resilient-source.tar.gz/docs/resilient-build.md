# Resilient VPN build record

Public fork: https://github.com/BehnamYo/iran-resilient-vpn

Baseline: official Hiddify v4.1.1, commit `abbd671bf6bf05195acd4158c714bff267cada8f`.
Flutter 3.38.5, commit `f6ff1529fd6d8af5f706051d9251ac9231c83407`.
Java 17; Gradle 8.7; AGP 8.6.0; Kotlin 2.1.0; Android SDK 36; NDK 28.2.13676358.
Native core: official hiddify-next-core v4.1.0 Android archive,
SHA-256 `6c4841f7aab23eb1fb17831349ecdfc3ca9c31553b8cbe5effd820cb12607f56`.
The release archive is used, not an independently built moving core submodule.

First unchanged baseline attempt failed: flutter_displaymode needs platform android-33.
Install platforms 33, 34, 35 and 36 for upstream plugin compatibility; app still targets 36.
No feature or dependency versions were changed to hide this failure.

Keep LICENSE.md and upstream notices. This noncommercial fork credits Hiddify:
https://github.com/hiddify/hiddify-app . Release via GitHub Actions with corresponding
public source. Do not distribute a debug-signed build as a release. Release signing
must be supplied through private CI secrets; never commit keys or passwords.

Verification pending: custom APK, device smoke test, tunnel test and
Iran network trial. None of these has passed merely because source exists.

Second baseline attempt found the new Android CLI extracted older platform archives
inside an extra directory (android-33/android-13/android.jar). Corrected only the
local SDK layout by moving that archive's files to android-33; no app source change.

Third attempt progressed past SDK parsing and failed because the preinstalled
Java 17 is incomplete (`jlink` absent). Use a complete Eclipse Temurin JDK 17;
CI already uses the official setup-java Temurin JDK, so no dependency pin change.
The complete JDK initially lacked this managed environment's trusted proxy CA.
Copied the existing system Java truststore into the local JDK; TLS verification
remains enabled. This is a local build-network setting, never an APK certificate override.

Unmodified production code baseline PASS: 275.4 seconds; universal APK 288.8 MB.
Only enabling the existing flutter_test dev dependency changed during compilation;
no runtime code, dependency versions or application behavior changed. New parser
modules were unreferenced. Baseline artifact is upstream debug-signed and not a release.

First custom build was killed by the workspace memory limit (cgroup oom_kill=1).
Limit Gradle to two workers, 3 GiB heap and in-process Kotlin compilation. This
changes build resource use, not the APK protocol engine. Final builds use ARM64
split APK output; the universal baseline includes unused architectures and is larger.

The stable app core submodule and official core v4.1.0 tag both resolve to
`c9d6f0f00b2eda34e4fb71863e4e0a62b3e931a0`. The generated native routing configuration
has not been inspected on Android; desktop proxy tests are not device routing proof.

A later local build failed while Gradle packed a transient `.rsync-tmp` cache file.
Build caching is disabled for reproducible operation in the synchronized workspace.

Source publication may use `resilient-source.tar.gz` in the public fork. The archive
is preferred-form source produced by git archive; only the unrelated prebuilt iOS
Libcore binary is export-ignored. Android core is fetched from the pinned official
release and checksum-verified. The root Actions workflow verifies the source archive
hash, extracts it, builds that exact source and includes it with the resulting APK.
