# Public source review — 3 October 2026

These repositories explicitly publish public free subscription feeds under MIT.
Their MIT notices are preserved in docs/licenses. Repository licensing is not a
server operator identity check: operators and continued availability are unknown.
All included profiles must remain labelled untested until local transfer checks pass.
Seven small shards from MatinGhanbari plus one 0xRadikal feed keep updates bounded;
these are eight feeds from two maintainers, not eight independent trust domains.
Both repositories showed commits on the fetch date. An update schedule advertised
by a maintainer is not an availability guarantee.

Reject disabled certificate checks, private destinations and unsupported transports.
Only generated protocol fields enter the engine; feed route, DNS, script and
promotional header settings are discarded. No private subscription is bundled.

| Public feed | Inspected revision | Revision time (UTC) | Download SHA-256 |
|---|---|---|---|
| MatinGhanbari/v2ray-configs: sub1.txt | `394b7bed42d57d7851ab55e605ac41fe062050f7` | 2026-10-03T17:45:40Z | `40991db3a95a6735385b589f8b8e1d97e0cefa4c725085a0d3e4ec4b31f8427c` |
| MatinGhanbari/v2ray-configs: sub2.txt | `394b7bed42d57d7851ab55e605ac41fe062050f7` | 2026-10-03T17:45:40Z | `faba778469c27ab4e8232151696677c472df8b05eab665dda7f9563c7c9936f0` |
| MatinGhanbari/v2ray-configs: sub3.txt | `394b7bed42d57d7851ab55e605ac41fe062050f7` | 2026-10-03T17:45:40Z | `d81ad35fcd25e412d163c0d31178d622be047352199e0153aac23b6e75793c81` |
| MatinGhanbari/v2ray-configs: sub4.txt | `394b7bed42d57d7851ab55e605ac41fe062050f7` | 2026-10-03T17:45:40Z | `ee844302a4281773fac2dcde2fec9c16b653f6a86d20b34b5000fc4a11405dc7` |
| MatinGhanbari/v2ray-configs: sub5.txt | `394b7bed42d57d7851ab55e605ac41fe062050f7` | 2026-10-03T17:45:40Z | `e1be08333726a04cdfb5ffb175b79700ff020e8f764a6b5eedda6d6216e3d286` |
| MatinGhanbari/v2ray-configs: sub6.txt | `394b7bed42d57d7851ab55e605ac41fe062050f7` | 2026-10-03T17:45:40Z | `f2a76b4ebbc863b26ef87ebcdb55b3b4e5b51f32479e658e28b3c71f2a3662f1` |
| MatinGhanbari/v2ray-configs: sub7.txt | `394b7bed42d57d7851ab55e605ac41fe062050f7` | 2026-10-03T17:45:40Z | `5126c683a34e275149cd16a4fdf98444a8266685d88f4783303ac039a20feb7d` |
| 0xRadikal/Free-v2ray-Configs: top100.txt | `dbff53d0c0782e3ddf1b469e908265ef8f349657` | 2026-10-03T18:38:37Z | `39fb802b900ddaa5517253893d9fb7f0247cdca68cde410b7bf0af37094d88a3` |
