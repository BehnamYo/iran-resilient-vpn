import 'dart:io';
import 'dart:convert';
import 'package:hiddify/features/resilience/data/subscription_parser.dart';
void main(List<String> args) {
  final root = Directory(args.single);
  final all = <String,String>{};
  final sources = <Map<String,String>>[];
  for (var i=1;i<=8;i++) {
    final owner = i<=7 ? 'MatinGhanbari' : '0xRadikal';
    final repo = i<=7 ? 'v2ray-configs' : 'Free-v2ray-Configs';
    final name = i<=7 ? 'sub$i.txt' : 'top100.txt';
    final id = i<=7 ? 'matin-$i' : 'radikal';
    final path = i<=7 ? 'subscriptions/v2ray/subs/$name' : name;
    final cs = parseSubscription(File('${root.path}/$owner-$name').readAsBytesSync(),id);
    File('assets/resilience/$id.txt').writeAsStringSync('${cs.map((c)=>c.shareUri).join('\n')}\n');
    for(final c in cs) {all.putIfAbsent(c.id,()=>c.shareUri);}
    sources.add({'id':id,'owner':owner,'repo':repo,'ref':'main','path':path});
    print('$id: ${cs.length} accepted');
  }
  if(all.isEmpty || all.length>maxProfiles) throw StateError('Invalid bootstrap count');
  File('assets/resilience/bootstrap.txt').writeAsStringSync('${all.values.join('\n')}\n');
  File('assets/resilience/sources.json').writeAsStringSync(const JsonEncoder.withIndent('  ').convert(sources));
  print('${all.length} unique, untested profiles');
}
