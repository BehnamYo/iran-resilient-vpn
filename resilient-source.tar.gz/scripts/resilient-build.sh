#!/usr/bin/env bash
set -euo pipefail
: "${ANDROID_HOME:?Android SDK required}"
: "${RESILIENT_KEYSTORE_BASE64:?Private release key missing}"
: "${RESILIENT_KEY_PASSWORD:?Private release password missing}"
: "${RESILIENT_STORE_PASSWORD:?Private release password missing}"
umask 077
trap 'rm -f android/key.properties android/app/resilient-release.jks' EXIT
printf '%s' "$RESILIENT_KEYSTORE_BASE64" | base64 --decode > android/app/resilient-release.jks
cat > android/key.properties <<KEYS
storeFile=resilient-release.jks
keyAlias=resilient
storePassword=$RESILIENT_STORE_PASSWORD
keyPassword=$RESILIENT_KEY_PASSWORD
KEYS
curl --fail --location --retry 3 -o /tmp/resilient-core.tar.gz https://github.com/hiddify/hiddify-next-core/releases/download/v4.1.0/hiddify-lib-android.tar.gz
printf '%s\n' '6c4841f7aab23eb1fb17831349ecdfc3ca9c31553b8cbe5effd820cb12607f56  /tmp/resilient-core.tar.gz' | sha256sum --check
mkdir -p android/app/libs
tar -xzf /tmp/resilient-core.tar.gz -C android/app/libs
flutter pub get
dart run build_runner build --delete-conflicting-outputs
dart run slang
javac -d /tmp/resilient-native-tests android/app/src/main/kotlin/com/hiddify/hiddify/StartAttemptGate.java test/native/StartAttemptGateTest.java
java -cp /tmp/resilient-native-tests StartAttemptGateTest
flutter test
flutter build apk --release --target-platform android-arm64 --split-per-abi --no-pub
mkdir -p release
cp build/app/outputs/flutter-apk/app-arm64-v8a-release.apk release/Resilient-VPN-arm64.apk
"$ANDROID_HOME/build-tools/36.0.0/apksigner" verify --verbose --print-certs release/Resilient-VPN-arm64.apk > release/signature.txt
"$ANDROID_HOME/build-tools/36.0.0/aapt" dump badging release/Resilient-VPN-arm64.apk > release/apk-info.txt
grep -q "package: name='org.goldis.resilientvpn'" release/apk-info.txt
cp LICENSE.md release/
if [[ -n "${RESILIENT_SOURCE_ARCHIVE:-}" ]]; then
  cp "$RESILIENT_SOURCE_ARCHIVE" release/source.tar.gz
else
  git archive --format=tar.gz --output=release/source.tar.gz HEAD
fi
(cd release && sha256sum Resilient-VPN-arm64.apk source.tar.gz > SHA256SUMS)
