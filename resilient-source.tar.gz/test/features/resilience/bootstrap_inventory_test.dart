import 'dart:convert';
import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:hiddify/features/resilience/data/snapshot_store.dart';

void main() {
  test('offline assets reconstruct all 434 validated profiles without network', () {
    final catalog = jsonDecode(File('assets/resilience/sources.json').readAsStringSync()) as List;
    final sources = <String, List<String>>{};
    for (final source in catalog) {
      sources[source['id'] as String] = File(
        'assets/resilience/${source['id']}.txt',
      ).readAsLinesSync().where((s) => s.isNotEmpty).toList();
    }
    final snapshot = Snapshot(revision: 1, updated: DateTime.utc(2026, 10, 3), sources: sources, etags: {});
    expect(snapshot.candidates.length, 434);
    expect(snapshot.sources.length, 8);
  });
}
