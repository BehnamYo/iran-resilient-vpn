import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter_test/flutter_test.dart';
import 'package:hiddify/features/resilience/data/subscription_fetcher.dart';
import 'package:hiddify/features/resilience/data/source_catalog.dart';

const source = Source(id: 'test', owner: 'owner', repo: 'repo', ref: 'main', path: 'configs.txt');
void main() {
  test('raw failure falls back to inline Contents API, never download_url', () async {
    final calls = <Uri>[];
    final f = SubscriptionFetcher(
      transport: (uri, headers) async {
        calls.add(uri);
        if (uri.host == 'raw.githubusercontent.com') throw const SocketException('blocked');
        return WireResponse(
          200,
          {},
          Uint8List.fromList(
            utf8.encode(
              jsonEncode({
                'encoding': 'base64',
                'content': base64.encode(utf8.encode('test-data')),
                'download_url': 'http://127.0.0.1/private',
              }),
            ),
          ),
        );
      },
    );
    expect(utf8.decode((await f.fetch(source, null)).bytes!), 'test-data');
    expect(calls.map((u) => u.host), ['raw.githubusercontent.com', 'api.github.com']);
  });
  test('304 retains cache and sends ETag', () async {
    final f = SubscriptionFetcher(
      transport: (u, h) async {
        expect(h['If-None-Match'], 'etag');
        return WireResponse(304, {}, Uint8List(0));
      },
    );
    expect((await f.fetch(source, 'etag')).notModified, isTrue);
  });
  test('429 honors retry-after without API amplification', () async {
    var calls = 0;
    final f = SubscriptionFetcher(
      transport: (u, h) async {
        calls++;
        return WireResponse(429, {'retry-after': '600'}, Uint8List(0));
      },
    );
    final r = await f.fetch(source, null);
    expect(r.retryAfter, const Duration(minutes: 10));
    expect(calls, 1);
  });
  test('reject redirect to private host and hostile API content', () async {
    final f = SubscriptionFetcher(
      transport: (u, h) async => u.host == 'raw.githubusercontent.com'
          ? WireResponse(302, {'location': 'https://127.0.0.1/private'}, Uint8List(0))
          : WireResponse(
              200,
              {},
              Uint8List.fromList(utf8.encode('{"encoding":"none","download_url":"https://127.0.0.1"}')),
            ),
    );
    expect(f.fetch(source, null), throwsFormatException);
  });
  test('compressed bomb and oversized transferred response rejected', () async {
    final bomb = Uint8List.fromList(gzip.encode(List.filled(8 * 1024 * 1024 + 1, 65)));
    expect(decodeBounded(bomb, 'gzip'), throwsFormatException);
    expect(decodeBounded(Uint8List(2 * 1024 * 1024 + 1), null), throwsFormatException);
  });
}
