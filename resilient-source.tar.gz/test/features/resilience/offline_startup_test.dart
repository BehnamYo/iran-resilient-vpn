import 'dart:io';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:hiddify/features/connection/data/connection_repository.dart';
import 'package:hiddify/features/profile/data/profile_path_resolver.dart';
import 'package:hiddify/features/resilience/data/engine_adapter.dart';
import 'package:hiddify/features/resilience/data/resilience_runtime.dart';
import 'package:hiddify/features/resilience/data/subscription_fetcher.dart';

class NoRepo implements ConnectionRepository {
  @override
  dynamic noSuchMethod(Invocation i) => super.noSuchMethod(i);
}

class OfflineEngine extends HiddifyEngineAdapter {
  OfflineEngine(Directory d) : super(NoRepo(), ProfilePathResolver(d));
  int stops = 0;
  @override
  Future<void> stop() async {
    stops++;
  }
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  test('real bundled assets initialize offline and clear unverified restored engine state', () async {
    const channel = MethodChannel('org.goldis.resilientvpn/network');
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger.setMockMethodCallHandler(
      channel,
      (call) async => null,
    );
    final dir = await Directory.systemTemp.createTemp('offline-start');
    final engine = OfflineEngine(dir);
    final runtime = ResilienceRuntime(
      dir,
      dir,
      engine,
      fetcher: SubscriptionFetcher(transport: (u, h) async => throw const SocketException('offline')),
    );
    try {
      await runtime.initialize();
      expect(runtime.ready, isTrue);
      expect(runtime.available.length, 434);
      expect(engine.stops, 1);
      await runtime.refresher!.refresh(force: true);
      expect(runtime.available.length, 434);
    } finally {
      runtime.dispose();
      await dir.delete(recursive: true);
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger.setMockMethodCallHandler(channel, null);
    }
  });
}
