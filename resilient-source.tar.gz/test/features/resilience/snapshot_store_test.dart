import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:hiddify/features/resilience/data/snapshot_store.dart';

String link(int i) =>
    'vless://00000000-0000-4000-8000-${i.toString().padLeft(12, '0')}@8.8.8.8:443?security=tls&sni=example.com';
Snapshot snap(int n) => Snapshot(
  revision: n,
  updated: DateTime.utc(2026),
  sources: {
    'test': [link(n)],
  },
  etags: {},
);
void main() {
  late Directory dir;
  setUp(() async {
    dir = await Directory.systemTemp.createTemp('resilient-test');
  });
  tearDown(() async {
    await dir.delete(recursive: true);
  });
  test('interruption before rename retains current and three historical snapshots', () async {
    final store = SnapshotStore(dir);
    for (var i = 1; i <= 5; i++) {
      await store.commitSnapshot(snap(i));
    }
    expect((await store.loadSnapshot())!.revision, 5);
    expect(dir.listSync().where((f) => f.path.endsWith('.json')).length, 4);
    final interrupted = SnapshotStore(
      dir,
      beforeReplace: () async {
        throw StateError('crash');
      },
    );
    await expectLater(interrupted.commitSnapshot(snap(6)), throwsStateError);
    expect((await store.loadSnapshot())!.revision, 5);
  });
  test('empty update cannot erase usable credentials', () async {
    final store = SnapshotStore(dir);
    await store.commitSnapshot(snap(1));
    await expectLater(
      store.commitSnapshot(Snapshot(revision: 2, updated: DateTime.now(), sources: {}, etags: {})),
      throwsFormatException,
    );
    expect((await store.loadSnapshot())!.revision, 1);
  });
  test('corrupt current recovers validated prior snapshot', () async {
    final store = SnapshotStore(dir);
    await store.commitSnapshot(snap(1));
    await store.commitSnapshot(snap(2));
    await File('${dir.path}/current.json').writeAsString('{bad');
    expect((await store.loadSnapshot())!.revision, 1);
  });
}
