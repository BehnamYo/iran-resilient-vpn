import 'dart:io';
import 'dart:typed_data';
import 'package:flutter_test/flutter_test.dart';
import 'package:hiddify/features/resilience/data/refresh_controller.dart';
import 'package:hiddify/features/resilience/data/snapshot_store.dart';
import 'package:hiddify/features/resilience/data/source_catalog.dart';
import 'package:hiddify/features/resilience/data/subscription_fetcher.dart';

void main() {
  test('empty and failed updates preserve credentials; 304 check survives relaunch', () async {
    final dir = await Directory.systemTemp.createTemp('refresh');
    try {
      final store = SnapshotStore(dir);
      final initial = Snapshot(
        revision: 1,
        updated: DateTime.utc(2020),
        sources: {
          'one': ['trojan://secret@8.8.8.8:443?sni=example.com'],
        },
        etags: {'one': 'tag'},
      );
      await store.commitSnapshot(initial);
      const src = Source(id: 'one', owner: 'owner', repo: 'repo', ref: 'main', path: 'c.txt');
      final empty = RefreshController(
        [src],
        store,
        SubscriptionFetcher(transport: (u, h) async => WireResponse(200, {}, Uint8List(0))),
        initial,
      );
      expect((await empty.refresh(force: true)).failedSources, 1);
      expect((await store.loadSnapshot())!.revision, 1);
      var calls = 0;
      final fetcher = SubscriptionFetcher(
        transport: (u, h) async {
          calls++;
          return WireResponse(304, {}, Uint8List(0));
        },
      );
      await RefreshController([src], store, fetcher, initial).refresh(force: true);
      await RefreshController([src], store, fetcher, initial).refresh();
      expect(calls, 1);
    } finally {
      await dir.delete(recursive: true);
    }
  });
}
