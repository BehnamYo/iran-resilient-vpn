import 'dart:io';
import 'dart:typed_data';
import 'package:flutter_test/flutter_test.dart';
import 'package:hiddify/features/resilience/data/tunnel_probe.dart';

class FakeSession implements ProbeSession {
  FakeSession(this.candidateId, this.reply);
  @override
  final String candidateId;
  final Future<ProbePayload> Function(Uri) reply;
  @override
  Future<ProbePayload> request(Uri uri) => reply(uri);
  @override
  void close() {}
}

void main() {
  final google = File('test/features/resilience/fixtures/google-probe.bin').readAsBytesSync();
  final mozilla = Uint8List.fromList('success\n'.codeUnits);
  Future<ProbePayload> valid(Uri u) async => ProbePayload(200, u.host == 'www.gstatic.com' ? google : mozilla);
  test('two authenticated endpoints plus sustained payload required', () async {
    var n = 0;
    final r = await TunnelProbe(sustain: Duration.zero).verify(
      'a',
      1,
      FakeSession('a', (u) {
        n++;
        return valid(u);
      }),
    );
    expect(r.state, ProbeState.verified);
    expect(n, 3);
  });
  test('one passing endpoint means limited', () async {
    final r = await TunnelProbe(sustain: Duration.zero).verify(
      'a',
      1,
      FakeSession('a', (u) async {
        if (u.host == 'www.gstatic.com') throw const SocketException('blocked');
        return valid(u);
      }),
    );
    expect(r.state, ProbeState.limited);
  });
  test('wrong content invalid TLS and stale candidate never verify', () async {
    for (final reply in <Future<ProbePayload> Function(Uri)>[
      (u) async => ProbePayload(200, Uint8List.fromList('wrong'.codeUnits)),
      (u) async => throw const HandshakeException('invalid certificate'),
    ]) {
      expect(
        (await TunnelProbe(sustain: Duration.zero).verify('a', 1, FakeSession('a', reply))).state,
        ProbeState.failed,
      );
    }
    expect((await TunnelProbe().verify('a', 1, FakeSession('b', valid))).state, ProbeState.failed);
  });
  test('stalled responses expire', () async {
    final r = await TunnelProbe(timeout: const Duration(milliseconds: 30), sustain: Duration.zero).verify(
      'a',
      1,
      FakeSession('a', (u) async {
        await Future<void>.delayed(const Duration(milliseconds: 100));
        return valid(u);
      }),
    );
    expect(r.state, ProbeState.failed);
  });
  test('dead local proxy cannot escape to live direct HTTP route', () async {
    final server = await HttpServer.bind(InternetAddress.loopbackIPv4, 0);
    var directHits = 0;
    server.listen((r) {
      directHits++;
      r.response.write('online');
      r.response.close();
    });
    final unused = await ServerSocket.bind(InternetAddress.loopbackIPv4, 0);
    final port = unused.port;
    await unused.close();
    final session = HttpProxySession('a', port);
    try {
      await expectLater(session.request(Uri.parse('http://127.0.0.1:${server.port}/')), throwsA(isA<Exception>()));
      expect(directHits, 0);
    } finally {
      session.close();
      await server.close(force: true);
    }
  });
}
