import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter_test/flutter_test.dart';
import 'package:hiddify/features/resilience/data/subscription_parser.dart';

String entry({String host = '8.8.8.8', String id = '00000000-0000-4000-8000-000000000001', String extra = ''}) =>
    'vless://$id@$host:443?security=tls&sni=example.com$extra#same';
void main() {
  List<dynamic> parse(String s) => parseSubscription(Uint8List.fromList(utf8.encode(s)), 'test');
  test('distinct credentials survive identical names; duplicates collapse', () {
    expect(parse('${entry()}\n${entry()}').length, 1);
    expect(parse('${entry()}\n${entry(id: '00000000-0000-4000-8000-000000000002')}').length, 2);
  });
  test('reject 2001 unique profiles atomically', () {
    final s = List.generate(
      2001,
      (i) => entry(id: '00000000-0000-4000-8000-${i.toString().padLeft(12, '0')}'),
    ).join('\n');
    expect(() => parse(s), throwsFormatException);
  });
  test('reject private special local and bypass TLS endpoints', () {
    for (final h in [
      '127.0.0.1',
      '10.2.3.4',
      '192.168.1.1',
      '169.254.1.1',
      '100.64.0.1',
      '[::1]',
      '[fc00::1]',
      '[::ffff:127.0.0.1]',
      'localhost',
      'router.local',
    ]) {
      expect(parse(entry(host: h)), isEmpty, reason: h);
    }
    expect(parse(entry(extra: '&allowInsecure=1')), isEmpty);
    expect(parse(entry(extra: '&skip-cert-verify=true')), isEmpty);
  });
  test('untrusted route DNS and script never enter generated config', () {
    final c = parseSubscription(
      Uint8List.fromList(utf8.encode(entry(extra: '&route=evil&dns=evil&script=evil'))),
      'test',
    );
    final output = encodeEngineProfile(c);
    expect(output, isNot(contains('evil')));
    expect(() => parse('{"outbounds":[],"route":{"final":"direct"}}'), throwsFormatException);
  });
  test('bounded input and entries fail atomically', () {
    expect(() => parse('x' * (8 * 1024 * 1024 + 1)), throwsFormatException);
    expect(() => parse(entry(extra: '&path=${'x' * 17000}')), throwsFormatException);
  });
  test('Base64 and transport fields are preserved without promotional headers', () {
    final c = parseSubscription(
      Uint8List.fromList(
        utf8.encode(
          base64.encode(utf8.encode('#name: promo\n${entry(extra: '&type=ws&path=%2Ftest&host=cdn.example.com')}')),
        ),
      ),
      'test',
    );
    expect(c.length, 1);
    expect(encodeEngineProfile(c), contains('/test'));
    expect(encodeEngineProfile(c), isNot(contains('promo')));
  });
}
