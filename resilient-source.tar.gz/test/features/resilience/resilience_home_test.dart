import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:hiddify/features/resilience/widget/resilience_home.dart';
import 'package:hiddify/features/resilience/model/selection_state.dart';

void main() {
  testWidgets('cached offline count, truthful states, retry and consent cancellation', (tester) async {
    for (final entry in {
      SelectionPhase.idle: 'Ready offline',
      SelectionPhase.verified: 'Verified',
      SelectionPhase.limited: 'Limited',
      SelectionPhase.testing: 'Testing',
      SelectionPhase.paused: 'Continue testing',
      SelectionPhase.permissionCancelled: 'VPN permission cancelled',
    }.entries) {
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: StatusPanel(state: SelectionState(entry.key), count: 434, fa: false, onConnect: () {}, onStop: () {}),
          ),
        ),
      );
      expect(find.textContaining(entry.value), findsWidgets);
      expect(find.textContaining('434'), findsOneWidget);
    }
  });
  testWidgets('Persian RTL at 200 percent text size remains scrollable', (tester) async {
    await tester.pumpWidget(
      MaterialApp(
        home: MediaQuery(
          data: const MediaQueryData(textScaler: TextScaler.linear(2)),
          child: Scaffold(
            body: SingleChildScrollView(
              child: StatusPanel(
                state: const SelectionState(SelectionPhase.paused),
                count: 434,
                fa: true,
                onConnect: () {},
                onStop: () {},
              ),
            ),
          ),
        ),
      ),
    );
    expect(tester.takeException(), isNull);
    final direction = Directionality.of(tester.element(find.text('ادامه آزمایش')));
    expect(direction, TextDirection.rtl);
  });
}
