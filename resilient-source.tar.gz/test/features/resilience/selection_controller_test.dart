import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:fake_async/fake_async.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:hiddify/features/resilience/data/engine_adapter.dart';
import 'package:hiddify/features/resilience/data/tunnel_probe.dart';
import 'package:hiddify/features/resilience/data/subscription_parser.dart';
import 'package:hiddify/features/resilience/model/candidate.dart';
import 'package:hiddify/features/resilience/domain/selection_controller.dart';
import 'package:hiddify/features/resilience/data/history_store.dart';
import 'package:hiddify/features/resilience/model/selection_state.dart';

class FakeEngine implements EngineAdapter {
  final starts = <String>[];
  int active = 0, maxActive = 0;
  bool deny = false, stall = false;
  @override
  Future<void> start(Candidate c) async {
    starts.add(c.id);
    if (deny) throw VpnConsentCancelled();
    if (stall) await Completer<void>().future;
    active++;
    if (active > maxActive) maxActive = active;
  }

  @override
  Future<void> stop() async {
    active = 0;
  }

  @override
  ProbeSession probeSession(String id) => throw UnimplementedError();
}

List<Candidate> candidates() => parseSubscription(
  Uint8List.fromList(
    utf8.encode(
      List.generate(
        20,
        (i) => 'trojan://password$i@8.8.8.8:443?sni=example.com${i.isOdd ? '&type=ws&path=%2Fx' : ''}',
      ).join('\n'),
    ),
  ),
  'test',
);
ProbeResult result(Candidate c, int g, ProbeState state) => ProbeResult(
  candidateId: c.id,
  generation: g,
  state: state,
  stage: 'test',
  timestamp: DateTime.utc(2026),
  duration: Duration.zero,
);
void main() {
  test('last success first, exactly one tunnel and healthy connection stays', () {
    fakeAsync((clock) {
      final cs = candidates(), engine = FakeEngine(), history = HistoryStore();
      history.success['wifi'] = cs[4].id;
      final ctrl = SelectionController(
        engine,
        history,
        verify: (c, g) async => result(c, g, ProbeState.verified),
        now: () => DateTime.utc(2026).add(clock.elapsed),
      );
      ctrl.connect(cs, 'wifi').listen((_) {});
      clock.flushMicrotasks();
      expect(engine.starts, [cs[4].id]);
      expect(engine.maxActive, 1);
      expect(ctrl.current.phase, SelectionPhase.verified);
      ctrl.connect(cs, 'wifi');
      clock.flushMicrotasks();
      expect(engine.starts.length, 1);
    });
  });
  test('failed transports diversify and 90 second budget stops scanning', () {
    fakeAsync((clock) {
      final cs = candidates(), engine = FakeEngine();
      final ctrl = SelectionController(
        engine,
        HistoryStore(),
        verify: (c, g) async => result(c, g, ProbeState.failed),
        now: () => DateTime.utc(2026).add(clock.elapsed),
      );
      ctrl.connect(cs, 'wifi').listen((_) {});
      clock.flushMicrotasks();
      clock.elapse(const Duration(seconds: 91));
      clock.flushMicrotasks();
      expect(engine.starts.length, greaterThan(1));
      expect(cs.firstWhere((c) => c.id == engine.starts[1]).transportGroup, isNot(cs.first.transportGroup));
      expect(engine.maxActive, 1);
      expect(ctrl.current.phase, SelectionPhase.paused);
    });
  });
  test('12 second engine timeout and cancelled permission stop safely', () {
    fakeAsync((clock) {
      final engine = FakeEngine()..stall = true;
      final ctrl = SelectionController(
        engine,
        HistoryStore(),
        verify: (c, g) async => result(c, g, ProbeState.verified),
        now: () => DateTime.utc(2026).add(clock.elapsed),
      );
      ctrl.connect(candidates(), 'wifi').listen((_) {});
      clock.flushMicrotasks();
      clock.elapse(const Duration(seconds: 12));
      clock.flushMicrotasks();
      expect(ctrl.history.records.length, 1);
      expect(ctrl.history.records.first['stage'], 'timeout');
      ctrl.cancel();
      clock.flushMicrotasks();
      expect(ctrl.current.phase, SelectionPhase.idle);
      final denied = FakeEngine()..deny = true;
      final ctl = SelectionController(
        denied,
        HistoryStore(),
        verify: (c, g) async => result(c, g, ProbeState.verified),
      );
      ctl.connect(candidates(), 'wifi').listen((_) {});
      clock.flushMicrotasks();
      expect(ctl.current.phase, SelectionPhase.permissionCancelled);
      expect(denied.starts.length, 1);
    });
  });
  test('budget continuation reaches every candidate despite expired cooldowns', () {
    fakeAsync((clock) {
      final cs = candidates(), engine = FakeEngine();
      final ctrl = SelectionController(
        engine,
        HistoryStore(),
        verify: (c, g) async => result(c, g, ProbeState.failed),
        now: () => DateTime.utc(2026).add(clock.elapsed),
      );
      for (var i = 0; i < 10; i++) {
        ctrl.connect(cs, 'wifi');
        clock.flushMicrotasks();
        clock.elapse(const Duration(seconds: 91));
      }
      expect(engine.starts.toSet(), cs.map((c) => c.id).toSet());
      ctrl.cancel();
      clock.flushMicrotasks();
    });
  });
  test('late success from previous network cannot verify or restart', () {
    fakeAsync((clock) {
      final pending = Completer<ProbeResult>();
      final cs = candidates(), engine = FakeEngine();
      final ctrl = SelectionController(engine, HistoryStore(), verify: (c, g) => pending.future);
      ctrl.connect(cs, 'wifi').listen((_) {});
      clock.flushMicrotasks();
      ctrl.networkChanged('mobile');
      clock.flushMicrotasks();
      pending.complete(result(cs.first, 0, ProbeState.verified));
      clock.flushMicrotasks();
      expect(ctrl.current.phase, SelectionPhase.idle);
      expect(engine.active, 0);
      expect(engine.starts.length, 1);
    });
  });
}
