import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter_test/flutter_test.dart';
import 'package:hiddify/features/resilience/data/history_store.dart';
import 'package:hiddify/features/resilience/data/subscription_parser.dart';
import 'package:hiddify/features/resilience/model/probe_result.dart';

void main() {
  test('verified credentials survive a feed removing the candidate and app relaunch', () async {
    final dir = await Directory.systemTemp.createTemp('history');
    try {
      final c = parseSubscription(
        Uint8List.fromList(utf8.encode('trojan://retained@8.8.8.8:443?sni=example.com')),
        'source',
      ).single;
      final h = HistoryStore(dir);
      h.record(
        c,
        'wifi',
        ProbeResult(
          candidateId: c.id,
          generation: 1,
          state: ProbeState.verified,
          stage: 'verified',
          timestamp: DateTime.now(),
          duration: Duration.zero,
        ),
      );
      await h.flush();
      final restored = HistoryStore(dir);
      await restored.load();
      expect(restored.knownWorking.single.id, c.id);
      await restored.clear();
      expect(restored.knownWorking, isEmpty);
    } finally {
      await dir.delete(recursive: true);
    }
  });
}
