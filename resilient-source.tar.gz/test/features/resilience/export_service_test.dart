import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:hiddify/features/resilience/data/export_service.dart';
import 'package:hiddify/features/resilience/data/history_store.dart';
import 'package:hiddify/features/resilience/data/snapshot_store.dart';

void main() {
  test('diagnostics exclude credentials identities and URLs; profile export needs consent', () async {
    final dir = await Directory.systemTemp.createTemp('export');
    try {
      final h = HistoryStore();
      h.records.add({
        'id': 'privateID',
        'host': 'secret.example',
        'url': 'https://user:pass@example.com?token=secret',
        'protocol': 'trojan',
        'result': 'failed',
        'stage': 'timeout',
        'milliseconds': 100,
      });
      final s = Snapshot(
        revision: 1,
        updated: DateTime.now(),
        sources: {
          'local': ['trojan://supersecret@8.8.8.8:443?sni=example.com'],
        },
        etags: {},
      );
      final e = ExportService(dir, h, () => s);
      final file = await e.exportDiagnostics();
      final text = await file.readAsString();
      for (final secret in ['privateID', 'secret.example', 'user:pass', 'token', 'supersecret', '8.8.8.8']) {
        expect(text, isNot(contains(secret)));
      }
      await expectLater(e.exportProfiles(includeSecrets: false), throwsStateError);
      expect(await (await e.exportProfiles(includeSecrets: true)).readAsString(), contains('supersecret'));
    } finally {
      await dir.delete(recursive: true);
    }
  });
}
