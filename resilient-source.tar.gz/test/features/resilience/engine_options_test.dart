import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:fpdart/fpdart.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:hiddify/features/connection/data/connection_repository.dart';
import 'package:hiddify/features/profile/data/profile_path_resolver.dart';
import 'package:hiddify/features/profile/model/profile_entity.dart';
import 'package:hiddify/features/settings/data/config_option_repository.dart';
import 'package:hiddify/features/settings/model/config_option_failure.dart';
import 'package:hiddify/hiddifycore/hiddify_core_service.dart';
import 'package:hiddify/singbox/model/singbox_config_option.dart';

class StubRef implements Ref {
  @override
  T read<T>(ProviderListenable<T> provider) => true as T;
  @override
  dynamic noSuchMethod(Invocation i) => super.noSuchMethod(i);
}

class StubWarp implements SingboxWarpOption {
  @override
  bool get enable => false;
  @override
  dynamic noSuchMethod(Invocation i) => super.noSuchMethod(i);
}

class StubOptions implements SingboxConfigOption {
  @override
  SingboxWarpOption get warp => StubWarp();
  @override
  SingboxWarpOption get warp2 => StubWarp();
  @override
  dynamic noSuchMethod(Invocation i) => super.noSuchMethod(i);
}

class StubConfig implements ConfigOptionRepository {
  @override
  Either<ConfigOptionFailure, SingboxConfigOption> fullOptionsOverrided(String? p) => right(StubOptions());
  @override
  dynamic noSuchMethod(Invocation i) => super.noSuchMethod(i);
}

class RejectSettings implements HiddifyCoreService {
  @override
  TaskEither<String, Unit> changeOptions(SingboxConfigOption o) => TaskEither.left('rejected');
  @override
  dynamic noSuchMethod(Invocation i) => super.noSuchMethod(i);
}

void main() {
  test('engine settings rejection cannot be reported as applied', () async {
    final dir = Directory.systemTemp;
    final repo = ConnectionRepositoryImpl(
      ref: StubRef(),
      directories: (baseDir: dir, workingDir: dir, tempDir: dir),
      singbox: RejectSettings(),
      configOptionRepository: StubConfig(),
      profilePathResolver: ProfilePathResolver(dir),
    );
    final r = await repo
        .applyConfigOption(ProfileEntity.local(id: 'test', active: true, name: 'test', lastUpdate: DateTime.now()))
        .run();
    expect(r.isLeft(), isTrue);
    expect(repo.configOptionsSnapshot, isNull);
  });
}
