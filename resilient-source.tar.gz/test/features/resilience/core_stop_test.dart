import 'package:flutter_test/flutter_test.dart';
import 'package:hiddify/hiddifycore/core_interface/core_interface.dart';
import 'package:hiddify/hiddifycore/hiddify_core_service.dart';
import 'package:hiddify/singbox/model/core_status.dart';
import 'engine_options_test.dart' show StubRef;

class FailedStop extends CoreInterface {
  @override
  Future<bool> stop() async => false;
}

void main() {
  test('native stop failure cannot publish stopped status', () async {
    final service = HiddifyCoreService(StubRef(), core: FailedStop());
    service.currentState = const CoreStatus.started();
    final result = await service.stop().run();
    expect(result.isLeft(), isTrue);
    expect(service.currentState, const CoreStatus.started());
    await service.statusController.close();
  });
}
