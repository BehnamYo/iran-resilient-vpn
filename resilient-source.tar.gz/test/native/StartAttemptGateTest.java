import com.hiddify.hiddify.StartAttemptGate;
public final class StartAttemptGateTest {
  public static void main(String[] args) {
    StartAttemptGate gate = new StartAttemptGate();
    long old = gate.begin();
    gate.awaitPermission(old);
    gate.cancel();
    if (gate.begin() != -1) throw new AssertionError("overlapping prompt");
    if (gate.consumePermission() != -1) throw new AssertionError("late grant accepted");
    long next = gate.begin();
    if (!gate.isCurrent(next) || gate.isCurrent(old)) throw new AssertionError("generation");
    gate.awaitPermission(next);
    if (gate.consumePermission() != next) throw new AssertionError("current grant lost");
    gate.cancel();
    if (gate.isCurrent(next)) throw new AssertionError("cancelled start accepted");
    System.out.println("Native consent generation tests passed");
  }
}
